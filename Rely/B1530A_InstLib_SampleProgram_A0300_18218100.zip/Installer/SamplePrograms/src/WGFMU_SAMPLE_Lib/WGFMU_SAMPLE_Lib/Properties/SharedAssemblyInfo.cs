using System.Reflection;

[assembly: AssemblyCompany("Agilent Technologies")]
[assembly: AssemblyCopyright("Copyright (C) Agilent Technologies 2008-2011")]

[assembly: AssemblyVersion("2.0.0.0")]
//[assembly: AssemblyFileVersion("2.0.0.0")]


Filename                        Description
--------------------------------------------------------------------
CSVReader.cs                    Data file (CSV) reader class
DialogGraph.Designer.cs         Enlarged graph form (designer)
DialogGraph.cs                  Enlarged graph form
Digitize.cs                     Digitization (binarization) class
DrawGraph.cs                    Graph drawer class
FFT.cs                          Fast Fourier Transform (FFT) class
Histogram.cs                    Binning class
MainWindow.Designer.cs          Main window form (designer)
MainWindow.cs                   Main window form
MovingAverage.cs                Moving average filter function
Program.cs                      Application bootstrap (designer)
SimplexMethod.cs                Simplex method class
Tau.cs                          Tau calculation class
document.ico                    Icon file (application)
--------------------------------------------------------------------
img\35FLOPPY.ICO                Icon file (3.5" FDD)
img\525FLOP1.ICO                Icon file (5.25" FDD)
img\CDDRIVE.ICO                 Icon file (CD-ROM Drive)
img\CLSDFOLD.ICO                Icon file (Closed Folder)
img\CRDFLE08.ICO                Icon file (Card File)
img\DRIVE.ICO                   Icon file (Hard Drive)
img\DRIVENET.ICO                Icon file (Network Drive)
img\MYCOMP.ICO                  Icon file (My Computer)
img\OPENFOLD.ICO                Icon file (Opened Folder)
img\QUESTION.ICO                Icon file (Unknown)
img\document.ico                Icon file (Document)
--------------------------------------------------------------------

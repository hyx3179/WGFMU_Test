﻿namespace NBTI
{
    partial class NBTI_Form
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label Labelx6;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.textBoxSweepVgStart = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBoxSweepVgStop = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.textBoxSweepVd = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxSweepStepNum = new System.Windows.Forms.TextBox();
            this.textBoxSweepDelayDualSweep = new System.Windows.Forms.TextBox();
            this.textBoxSweepHold = new System.Windows.Forms.TextBox();
            this.textBoxSweepDelay = new System.Windows.Forms.TextBox();
            this.textBoxSweepAveragingTime = new System.Windows.Forms.TextBox();
            this.textBoxSweepStepRise = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBoxSamplingMeasAveragingTime = new System.Windows.Forms.TextBox();
            this.comboBoxSamplingMode = new System.Windows.Forms.ComboBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.textBoxSamplingMeasDelay = new System.Windows.Forms.TextBox();
            this.textBoxSamplingHold = new System.Windows.Forms.TextBox();
            this.comboBoxSweepType = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBoxSamplingMeasInterval = new System.Windows.Forms.TextBox();
            this.groupVgSweep = new System.Windows.Forms.GroupBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBoxSweepStepDelay = new System.Windows.Forms.TextBox();
            this.textBoxSamplingVg = new System.Windows.Forms.TextBox();
            this.textBoxSamplingVd = new System.Windows.Forms.TextBox();
            this.textBoxSampingMeasPoints = new System.Windows.Forms.TextBox();
            this.tabMeasSequenceSetup = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBoxStressToMeasEdge = new System.Windows.Forms.TextBox();
            this.textBoxVdSequenceDelay = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButtonOTF = new System.Windows.Forms.RadioButton();
            this.radioButtonSweep = new System.Windows.Forms.RadioButton();
            this.radioButtonSampling = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBoxStressDelayReferenceMeas = new System.Windows.Forms.TextBox();
            this.checkBoxReferenceMeas = new System.Windows.Forms.CheckBox();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxPostMeasDelay = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.checkBoxEnablePostMeas = new System.Windows.Forms.CheckBox();
            this.comboBoxMeasIntervalMode = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.textBoxMeasIterationNumber = new System.Windows.Forms.TextBox();
            this.textBoxIterativeMeasInterval = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.textBoxSweepVdPulseBase = new System.Windows.Forms.TextBox();
            this.textBoxOTFMeasDelay = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBoxSweepVdPulseWidth = new System.Windows.Forms.TextBox();
            this.textBoxOTFdVg = new System.Windows.Forms.TextBox();
            this.textBoxOTFVd = new System.Windows.Forms.TextBox();
            this.buttonLoad = new System.Windows.Forms.Button();
            this.textBoxOTFMeasAveragingTime = new System.Windows.Forms.TextBox();
            this.buttonExecMeas = new System.Windows.Forms.Button();
            this.textBoxOTFEdge = new System.Windows.Forms.TextBox();
            this.validPattern = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.buttonClose = new System.Windows.Forms.Button();
            this.textBoxSweepPulsePeriod = new System.Windows.Forms.TextBox();
            this.textBoxSweepVgPulseBase = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.Labelx2 = new System.Windows.Forms.Label();
            this.Labelx4 = new System.Windows.Forms.Label();
            this.Labelx3 = new System.Windows.Forms.Label();
            this.textBoxSweepVdPulseDelay = new System.Windows.Forms.TextBox();
            this.checkBoxDualSweep = new System.Windows.Forms.CheckBox();
            this.groupSweepVgPulse = new System.Windows.Forms.GroupBox();
            this.textBoxSweepVgPulseWidth = new System.Windows.Forms.TextBox();
            this.textBoxSweepVgPulseLeadingEdge = new System.Windows.Forms.TextBox();
            this.textBoxSweepVgPulseDelay = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.checkBoxSweepVdPulse = new System.Windows.Forms.CheckBox();
            this.groupSweepVdPulse = new System.Windows.Forms.GroupBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBoxSweepVdPulseLeadingEdge = new System.Windows.Forms.TextBox();
            this.tabSamplingSetup = new System.Windows.Forms.TabPage();
            this.label39 = new System.Windows.Forms.Label();
            this.textBoxSamplingExtraDelay = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.comboBoxGateChVMeasRange = new System.Windows.Forms.ComboBox();
            this.checkBoxDrainMeas = new System.Windows.Forms.CheckBox();
            this.label48 = new System.Windows.Forms.Label();
            this.comboBoxGateChForceRange = new System.Windows.Forms.ComboBox();
            this.label51 = new System.Windows.Forms.Label();
            this.comboBoxGateChMeasMode = new System.Windows.Forms.ComboBox();
            this.comboBoxGateChOperationMode = new System.Windows.Forms.ComboBox();
            this.tabStressSetup = new System.Windows.Forms.TabControl();
            this.tabAccStressTimeSetup = new System.Windows.Forms.TabPage();
            this.dataViewStressList = new System.Windows.Forms.DataGridView();
            this.StressNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ListAccumulatedStressTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabStressVgSetup = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.textBoxVgRangeChangeHold = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.comboBoxVgStressCurrentRange = new System.Windows.Forms.ComboBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxStressVg = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.radioButtonPulseStress = new System.Windows.Forms.RadioButton();
            this.radioButtonDCStress = new System.Windows.Forms.RadioButton();
            this.groupACStressVgPulse = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBoxStressPulseFreq = new System.Windows.Forms.ComboBox();
            this.textBoxStressVgBase = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxStressVgPulseDuty = new System.Windows.Forms.TextBox();
            this.textBoxStressVgPulseLeadingEdge = new System.Windows.Forms.TextBox();
            this.textBoxStressVgPulseDelay = new System.Windows.Forms.TextBox();
            this.tabStressVdSetup = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.textBoxVdRangeChangeHold = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBoxVdStressCurrentRange = new System.Windows.Forms.ComboBox();
            this.textBoxStressVd = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.groupVdACStress = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.checkBoxVdPulseStress = new System.Windows.Forms.CheckBox();
            this.textBoxStressVdPulseBase = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBoxStressVdPulseDuty = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBoxStressVdPulseLeadingEdge = new System.Windows.Forms.TextBox();
            this.Labelx1 = new System.Windows.Forms.Label();
            this.textBoxStressVdPulseDelay = new System.Windows.Forms.TextBox();
            this.textBoxGateChHwSkew = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.tabPivSetup = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.checkBoxGateMeas = new System.Windows.Forms.CheckBox();
            this.textBoxDrainChHwSkew = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.comboBoxDrainChOperationMode = new System.Windows.Forms.ComboBox();
            this.comboBoxDrainChMeasMode = new System.Windows.Forms.ComboBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabChannelSetup = new System.Windows.Forms.TabControl();
            this.tabGateChSetup = new System.Windows.Forms.TabPage();
            this.comboBoxGateChIMeasRange = new System.Windows.Forms.ComboBox();
            this.label64 = new System.Windows.Forms.Label();
            this.comboBoxGateCh = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tabDrainChSetup = new System.Windows.Forms.TabPage();
            this.comboBoxDrainChIMeasRange = new System.Windows.Forms.ComboBox();
            this.label62 = new System.Windows.Forms.Label();
            this.comboBoxDrainCh = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxDrainChVMeasRange = new System.Windows.Forms.ComboBox();
            this.comboBoxDrainChForceRange = new System.Windows.Forms.ComboBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBoxBiasSource2BiasV = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.comboBoxBiasSource2Type = new System.Windows.Forms.ComboBox();
            this.label72 = new System.Windows.Forms.Label();
            this.comboBoxBiasSource2Ch = new System.Windows.Forms.ComboBox();
            this.textBoxBiasSource2Compliance = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBoxBiasSource1BiasV = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.comboBoxBiasSource1Type = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.comboBoxBiasSource1Ch = new System.Windows.Forms.ComboBox();
            this.textBoxBiasSource1Compliance = new System.Windows.Forms.TextBox();
            this.tabOTFSetup = new System.Windows.Forms.TabPage();
            this.label44 = new System.Windows.Forms.Label();
            this.textBoxOTFStepDelay = new System.Windows.Forms.TextBox();
            this.tabMeasurementSetup = new System.Windows.Forms.TabControl();
            this.tabSweepSetup = new System.Windows.Forms.TabPage();
            this.buttonConfig = new System.Windows.Forms.Button();
            this.buttonSaveSetup = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            Labelx6 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.groupVgSweep.SuspendLayout();
            this.tabMeasSequenceSetup.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupSweepVgPulse.SuspendLayout();
            this.groupSweepVdPulse.SuspendLayout();
            this.tabSamplingSetup.SuspendLayout();
            this.tabStressSetup.SuspendLayout();
            this.tabAccStressTimeSetup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataViewStressList)).BeginInit();
            this.tabStressVgSetup.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupACStressVgPulse.SuspendLayout();
            this.tabStressVdSetup.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupVdACStress.SuspendLayout();
            this.tabPivSetup.SuspendLayout();
            this.tabChannelSetup.SuspendLayout();
            this.tabGateChSetup.SuspendLayout();
            this.tabDrainChSetup.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabOTFSetup.SuspendLayout();
            this.tabMeasurementSetup.SuspendLayout();
            this.tabSweepSetup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // Labelx6
            // 
            Labelx6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Labelx6.Location = new System.Drawing.Point(6, 135);
            Labelx6.Name = "Labelx6";
            Labelx6.Size = new System.Drawing.Size(72, 30);
            Labelx6.TabIndex = 3;
            Labelx6.Text = "Pulse Delay (s)";
            Labelx6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSweepVgStart
            // 
            this.textBoxSweepVgStart.Location = new System.Drawing.Point(112, 24);
            this.textBoxSweepVgStart.Name = "textBoxSweepVgStart";
            this.textBoxSweepVgStart.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepVgStart.TabIndex = 0;
            this.textBoxSweepVgStart.Text = "0.0";
            this.textBoxSweepVgStart.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepVgStart_Validating);
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(6, 24);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(88, 16);
            this.label19.TabIndex = 3;
            this.label19.Text = "Start (V)";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSweepVgStop
            // 
            this.textBoxSweepVgStop.Location = new System.Drawing.Point(112, 48);
            this.textBoxSweepVgStop.Name = "textBoxSweepVgStop";
            this.textBoxSweepVgStop.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepVgStop.TabIndex = 1;
            this.textBoxSweepVgStop.Text = "0.0";
            this.textBoxSweepVgStop.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepVgStop_Validating);
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(6, 48);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(88, 16);
            this.label20.TabIndex = 3;
            this.label20.Text = "Stop (V)";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(6, 235);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(75, 40);
            this.label31.TabIndex = 3;
            this.label31.Text = "Dual Sweep Delay(s)";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 143);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(88, 43);
            this.label23.TabIndex = 3;
            this.label23.Text = "Measurement Delay (s)";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(5, 179);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(89, 37);
            this.label24.TabIndex = 3;
            this.label24.Text = "Averaging Time (s)";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSweepVd
            // 
            this.textBoxSweepVd.Location = new System.Drawing.Point(110, 16);
            this.textBoxSweepVd.Name = "textBoxSweepVd";
            this.textBoxSweepVd.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepVd.TabIndex = 0;
            this.textBoxSweepVd.Text = "0.0";
            this.textBoxSweepVd.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepVd_Validating);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(16, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 16);
            this.label10.TabIndex = 3;
            this.label10.Text = "Vd (V)";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSweepStepNum
            // 
            this.textBoxSweepStepNum.Location = new System.Drawing.Point(112, 72);
            this.textBoxSweepStepNum.Name = "textBoxSweepStepNum";
            this.textBoxSweepStepNum.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepStepNum.TabIndex = 2;
            this.textBoxSweepStepNum.Text = "0";
            this.textBoxSweepStepNum.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepStepNum_Validating);
            // 
            // textBoxSweepDelayDualSweep
            // 
            this.textBoxSweepDelayDualSweep.Location = new System.Drawing.Point(111, 247);
            this.textBoxSweepDelayDualSweep.Name = "textBoxSweepDelayDualSweep";
            this.textBoxSweepDelayDualSweep.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepDelayDualSweep.TabIndex = 8;
            this.textBoxSweepDelayDualSweep.Text = "0.0";
            this.textBoxSweepDelayDualSweep.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepDelayDualSweep_Validating);
            // 
            // textBoxSweepHold
            // 
            this.textBoxSweepHold.Location = new System.Drawing.Point(112, 127);
            this.textBoxSweepHold.Name = "textBoxSweepHold";
            this.textBoxSweepHold.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepHold.TabIndex = 4;
            this.textBoxSweepHold.Text = "0.0";
            this.textBoxSweepHold.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepHold_Validating);
            // 
            // textBoxSweepDelay
            // 
            this.textBoxSweepDelay.Location = new System.Drawing.Point(111, 153);
            this.textBoxSweepDelay.Name = "textBoxSweepDelay";
            this.textBoxSweepDelay.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepDelay.TabIndex = 5;
            this.textBoxSweepDelay.Text = "200E-9";
            this.textBoxSweepDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepDelay_Validating);
            // 
            // textBoxSweepAveragingTime
            // 
            this.textBoxSweepAveragingTime.Location = new System.Drawing.Point(111, 188);
            this.textBoxSweepAveragingTime.Name = "textBoxSweepAveragingTime";
            this.textBoxSweepAveragingTime.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepAveragingTime.TabIndex = 6;
            this.textBoxSweepAveragingTime.Text = "10E-9";
            this.textBoxSweepAveragingTime.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepAveragingTime_Validating);
            // 
            // textBoxSweepStepRise
            // 
            this.textBoxSweepStepRise.Location = new System.Drawing.Point(112, 98);
            this.textBoxSweepStepRise.Name = "textBoxSweepStepRise";
            this.textBoxSweepStepRise.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepStepRise.TabIndex = 3;
            this.textBoxSweepStepRise.Text = "100E-9";
            this.textBoxSweepStepRise.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepStepRise_Validating);
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(6, 98);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(64, 20);
            this.label25.TabIndex = 3;
            this.label25.Text = "Step Rise (sec)";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(7, 34);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(78, 24);
            this.label15.TabIndex = 18;
            this.label15.Text = "Sweep Type";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(6, 72);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(88, 16);
            this.label21.TabIndex = 3;
            this.label21.Text = "Step Num";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(6, 127);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(88, 16);
            this.label22.TabIndex = 3;
            this.label22.Text = "Hold (s)";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSamplingMeasAveragingTime
            // 
            this.textBoxSamplingMeasAveragingTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSamplingMeasAveragingTime.Location = new System.Drawing.Point(117, 245);
            this.textBoxSamplingMeasAveragingTime.Name = "textBoxSamplingMeasAveragingTime";
            this.textBoxSamplingMeasAveragingTime.Size = new System.Drawing.Size(56, 22);
            this.textBoxSamplingMeasAveragingTime.TabIndex = 7;
            this.textBoxSamplingMeasAveragingTime.Text = "10E-9";
            this.textBoxSamplingMeasAveragingTime.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSamplingMeasAveragingTime_Validating);
            // 
            // comboBoxSamplingMode
            // 
            this.comboBoxSamplingMode.FormattingEnabled = true;
            this.comboBoxSamplingMode.Items.AddRange(new object[] {
            "LINEAR",
            "LOG10",
            "LOG25"});
            this.comboBoxSamplingMode.Location = new System.Drawing.Point(96, 74);
            this.comboBoxSamplingMode.Name = "comboBoxSamplingMode";
            this.comboBoxSamplingMode.Size = new System.Drawing.Size(77, 21);
            this.comboBoxSamplingMode.TabIndex = 2;
            // 
            // label60
            // 
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(6, 66);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(69, 35);
            this.label60.TabIndex = 16;
            this.label60.Text = "Sampling Mode";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 15);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 16);
            this.label13.TabIndex = 12;
            this.label13.Text = "Vg (V)";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(6, 39);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(88, 16);
            this.label14.TabIndex = 11;
            this.label14.Text = "Vd (V)";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(6, 111);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(94, 21);
            this.label16.TabIndex = 14;
            this.label16.Text = "Stress Hold (s)";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(6, 239);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(88, 34);
            this.label18.TabIndex = 13;
            this.label18.Text = "Averaging Time (s)";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 143);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 16);
            this.label17.TabIndex = 8;
            this.label17.Text = "Meas Delay (s)";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(6, 170);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(107, 24);
            this.label34.TabIndex = 10;
            this.label34.Text = "Initial Interval (s)";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(6, 207);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(88, 32);
            this.label35.TabIndex = 9;
            this.label35.Text = "Sampling Points";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSamplingMeasDelay
            // 
            this.textBoxSamplingMeasDelay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSamplingMeasDelay.Location = new System.Drawing.Point(117, 140);
            this.textBoxSamplingMeasDelay.Name = "textBoxSamplingMeasDelay";
            this.textBoxSamplingMeasDelay.Size = new System.Drawing.Size(56, 22);
            this.textBoxSamplingMeasDelay.TabIndex = 4;
            this.textBoxSamplingMeasDelay.Text = "0.0";
            this.textBoxSamplingMeasDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSamplingMeasDelay_Validating);
            // 
            // textBoxSamplingHold
            // 
            this.textBoxSamplingHold.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSamplingHold.Location = new System.Drawing.Point(117, 108);
            this.textBoxSamplingHold.Name = "textBoxSamplingHold";
            this.textBoxSamplingHold.Size = new System.Drawing.Size(56, 22);
            this.textBoxSamplingHold.TabIndex = 3;
            this.textBoxSamplingHold.Text = "0.0";
            this.textBoxSamplingHold.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSamplingHold_Validating);
            // 
            // comboBoxSweepType
            // 
            this.comboBoxSweepType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxSweepType.FormattingEnabled = true;
            this.comboBoxSweepType.Items.AddRange(new object[] {
            "Staircase",
            "Ramp",
            "Pulsed IV"});
            this.comboBoxSweepType.Location = new System.Drawing.Point(88, 37);
            this.comboBoxSweepType.Name = "comboBoxSweepType";
            this.comboBoxSweepType.Size = new System.Drawing.Size(95, 21);
            this.comboBoxSweepType.TabIndex = 1;
            this.comboBoxSweepType.SelectedIndexChanged += new System.EventHandler(this.comboBoxSweepType_SelectedIndexChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBoxSweepVd);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(6, 348);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(193, 48);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Vd ";
            // 
            // textBoxSamplingMeasInterval
            // 
            this.textBoxSamplingMeasInterval.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSamplingMeasInterval.Location = new System.Drawing.Point(117, 169);
            this.textBoxSamplingMeasInterval.Name = "textBoxSamplingMeasInterval";
            this.textBoxSamplingMeasInterval.Size = new System.Drawing.Size(56, 22);
            this.textBoxSamplingMeasInterval.TabIndex = 5;
            this.textBoxSamplingMeasInterval.Text = "1E-6";
            this.textBoxSamplingMeasInterval.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSamplingMeasInterval_Validating);
            // 
            // groupVgSweep
            // 
            this.groupVgSweep.Controls.Add(this.label42);
            this.groupVgSweep.Controls.Add(this.textBoxSweepStepDelay);
            this.groupVgSweep.Controls.Add(this.textBoxSweepVgStart);
            this.groupVgSweep.Controls.Add(this.label19);
            this.groupVgSweep.Controls.Add(this.textBoxSweepVgStop);
            this.groupVgSweep.Controls.Add(this.label20);
            this.groupVgSweep.Controls.Add(this.label31);
            this.groupVgSweep.Controls.Add(this.label23);
            this.groupVgSweep.Controls.Add(this.label24);
            this.groupVgSweep.Controls.Add(this.textBoxSweepStepNum);
            this.groupVgSweep.Controls.Add(this.textBoxSweepDelayDualSweep);
            this.groupVgSweep.Controls.Add(this.textBoxSweepHold);
            this.groupVgSweep.Controls.Add(this.textBoxSweepDelay);
            this.groupVgSweep.Controls.Add(this.textBoxSweepAveragingTime);
            this.groupVgSweep.Controls.Add(this.textBoxSweepStepRise);
            this.groupVgSweep.Controls.Add(this.label25);
            this.groupVgSweep.Controls.Add(this.label21);
            this.groupVgSweep.Controls.Add(this.label22);
            this.groupVgSweep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupVgSweep.Location = new System.Drawing.Point(6, 66);
            this.groupVgSweep.Name = "groupVgSweep";
            this.groupVgSweep.Size = new System.Drawing.Size(193, 276);
            this.groupVgSweep.TabIndex = 2;
            this.groupVgSweep.TabStop = false;
            this.groupVgSweep.Text = "Vg Sweep";
            // 
            // label42
            // 
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(5, 213);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(89, 24);
            this.label42.TabIndex = 8;
            this.label42.Text = "Step Delay (s)";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSweepStepDelay
            // 
            this.textBoxSweepStepDelay.Location = new System.Drawing.Point(111, 219);
            this.textBoxSweepStepDelay.Name = "textBoxSweepStepDelay";
            this.textBoxSweepStepDelay.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepStepDelay.TabIndex = 7;
            this.textBoxSweepStepDelay.Text = "100E-9";
            this.textBoxSweepStepDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepStepDelay_Validating);
            // 
            // textBoxSamplingVg
            // 
            this.textBoxSamplingVg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSamplingVg.Location = new System.Drawing.Point(117, 12);
            this.textBoxSamplingVg.Name = "textBoxSamplingVg";
            this.textBoxSamplingVg.Size = new System.Drawing.Size(56, 22);
            this.textBoxSamplingVg.TabIndex = 0;
            this.textBoxSamplingVg.Text = "0.0";
            this.textBoxSamplingVg.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSamplingVg_Validating);
            // 
            // textBoxSamplingVd
            // 
            this.textBoxSamplingVd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSamplingVd.Location = new System.Drawing.Point(117, 36);
            this.textBoxSamplingVd.Name = "textBoxSamplingVd";
            this.textBoxSamplingVd.Size = new System.Drawing.Size(56, 22);
            this.textBoxSamplingVd.TabIndex = 1;
            this.textBoxSamplingVd.Text = "0.0";
            this.textBoxSamplingVd.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSamplingVd_Validating);
            // 
            // textBoxSampingMeasPoints
            // 
            this.textBoxSampingMeasPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSampingMeasPoints.Location = new System.Drawing.Point(117, 206);
            this.textBoxSampingMeasPoints.Name = "textBoxSampingMeasPoints";
            this.textBoxSampingMeasPoints.Size = new System.Drawing.Size(56, 22);
            this.textBoxSampingMeasPoints.TabIndex = 6;
            this.textBoxSampingMeasPoints.Text = "1";
            this.textBoxSampingMeasPoints.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSampingMeasPoints_Validating);
            // 
            // tabMeasSequenceSetup
            // 
            this.tabMeasSequenceSetup.Controls.Add(this.groupBox5);
            this.tabMeasSequenceSetup.Controls.Add(this.groupBox2);
            this.tabMeasSequenceSetup.Controls.Add(this.groupBox4);
            this.tabMeasSequenceSetup.Controls.Add(this.groupBox1);
            this.tabMeasSequenceSetup.Location = new System.Drawing.Point(4, 22);
            this.tabMeasSequenceSetup.Name = "tabMeasSequenceSetup";
            this.tabMeasSequenceSetup.Padding = new System.Windows.Forms.Padding(3);
            this.tabMeasSequenceSetup.Size = new System.Drawing.Size(205, 405);
            this.tabMeasSequenceSetup.TabIndex = 4;
            this.tabMeasSequenceSetup.Text = "Sequence";
            this.tabMeasSequenceSetup.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBoxStressToMeasEdge);
            this.groupBox5.Controls.Add(this.textBoxVdSequenceDelay);
            this.groupBox5.Controls.Add(this.label61);
            this.groupBox5.Controls.Add(this.label63);
            this.groupBox5.Location = new System.Drawing.Point(9, 79);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(190, 89);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Output Sequence";
            // 
            // textBoxStressToMeasEdge
            // 
            this.textBoxStressToMeasEdge.Location = new System.Drawing.Point(112, 19);
            this.textBoxStressToMeasEdge.Name = "textBoxStressToMeasEdge";
            this.textBoxStressToMeasEdge.Size = new System.Drawing.Size(56, 20);
            this.textBoxStressToMeasEdge.TabIndex = 0;
            this.textBoxStressToMeasEdge.Text = "100E-9";
            this.textBoxStressToMeasEdge.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressToMeasEdge_Validating);
            // 
            // textBoxVdSequenceDelay
            // 
            this.textBoxVdSequenceDelay.Location = new System.Drawing.Point(112, 50);
            this.textBoxVdSequenceDelay.Name = "textBoxVdSequenceDelay";
            this.textBoxVdSequenceDelay.Size = new System.Drawing.Size(56, 20);
            this.textBoxVdSequenceDelay.TabIndex = 1;
            this.textBoxVdSequenceDelay.Text = "0.0";
            this.textBoxVdSequenceDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxVdSequenceDelay_Validating);
            // 
            // label61
            // 
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(7, 16);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(113, 31);
            this.label61.TabIndex = 3;
            this.label61.Text = "Stress to Meas. Edge (s)";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label63
            // 
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(7, 47);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(113, 31);
            this.label63.TabIndex = 3;
            this.label63.Text = "Vd Sequence Delay (s)";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButtonOTF);
            this.groupBox2.Controls.Add(this.radioButtonSweep);
            this.groupBox2.Controls.Add(this.radioButtonSampling);
            this.groupBox2.Location = new System.Drawing.Point(9, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(190, 67);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Measurement Item";
            // 
            // radioButtonOTF
            // 
            this.radioButtonOTF.AutoSize = true;
            this.radioButtonOTF.Location = new System.Drawing.Point(19, 47);
            this.radioButtonOTF.Name = "radioButtonOTF";
            this.radioButtonOTF.Size = new System.Drawing.Size(49, 17);
            this.radioButtonOTF.TabIndex = 2;
            this.radioButtonOTF.TabStop = true;
            this.radioButtonOTF.Text = "OTF";
            this.radioButtonOTF.UseVisualStyleBackColor = true;
            // 
            // radioButtonSweep
            // 
            this.radioButtonSweep.AutoSize = true;
            this.radioButtonSweep.Location = new System.Drawing.Point(19, 31);
            this.radioButtonSweep.Name = "radioButtonSweep";
            this.radioButtonSweep.Size = new System.Drawing.Size(79, 17);
            this.radioButtonSweep.TabIndex = 1;
            this.radioButtonSweep.TabStop = true;
            this.radioButtonSweep.Text = "Sweep IV";
            this.radioButtonSweep.UseVisualStyleBackColor = true;
            // 
            // radioButtonSampling
            // 
            this.radioButtonSampling.AutoSize = true;
            this.radioButtonSampling.Location = new System.Drawing.Point(19, 15);
            this.radioButtonSampling.Name = "radioButtonSampling";
            this.radioButtonSampling.Size = new System.Drawing.Size(91, 17);
            this.radioButtonSampling.TabIndex = 0;
            this.radioButtonSampling.TabStop = true;
            this.radioButtonSampling.Text = "Id Sampling";
            this.radioButtonSampling.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBoxStressDelayReferenceMeas);
            this.groupBox4.Controls.Add(this.checkBoxReferenceMeas);
            this.groupBox4.Controls.Add(this.label36);
            this.groupBox4.Location = new System.Drawing.Point(6, 172);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(193, 77);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Reference Measurement";
            // 
            // textBoxStressDelayReferenceMeas
            // 
            this.textBoxStressDelayReferenceMeas.Location = new System.Drawing.Point(111, 38);
            this.textBoxStressDelayReferenceMeas.Name = "textBoxStressDelayReferenceMeas";
            this.textBoxStressDelayReferenceMeas.Size = new System.Drawing.Size(56, 20);
            this.textBoxStressDelayReferenceMeas.TabIndex = 1;
            this.textBoxStressDelayReferenceMeas.Text = "0.0";
            this.textBoxStressDelayReferenceMeas.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressDelayReferenceMeas_Validating);
            // 
            // checkBoxReferenceMeas
            // 
            this.checkBoxReferenceMeas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxReferenceMeas.Location = new System.Drawing.Point(6, 13);
            this.checkBoxReferenceMeas.Name = "checkBoxReferenceMeas";
            this.checkBoxReferenceMeas.Size = new System.Drawing.Size(92, 22);
            this.checkBoxReferenceMeas.TabIndex = 0;
            this.checkBoxReferenceMeas.Text = "Enable";
            // 
            // label36
            // 
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(3, 27);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(99, 40);
            this.label36.TabIndex = 0;
            this.label36.Text = "Ref. Meas. to Stress Delay (s)";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxPostMeasDelay);
            this.groupBox1.Controls.Add(this.label73);
            this.groupBox1.Controls.Add(this.checkBoxEnablePostMeas);
            this.groupBox1.Controls.Add(this.comboBoxMeasIntervalMode);
            this.groupBox1.Controls.Add(this.label52);
            this.groupBox1.Controls.Add(this.textBoxMeasIterationNumber);
            this.groupBox1.Controls.Add(this.textBoxIterativeMeasInterval);
            this.groupBox1.Controls.Add(this.label50);
            this.groupBox1.Controls.Add(this.label49);
            this.groupBox1.Location = new System.Drawing.Point(6, 255);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(193, 144);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Post Measurement";
            // 
            // textBoxPostMeasDelay
            // 
            this.textBoxPostMeasDelay.Location = new System.Drawing.Point(113, 40);
            this.textBoxPostMeasDelay.Name = "textBoxPostMeasDelay";
            this.textBoxPostMeasDelay.Size = new System.Drawing.Size(56, 20);
            this.textBoxPostMeasDelay.TabIndex = 1;
            this.textBoxPostMeasDelay.Text = "0.0";
            this.textBoxPostMeasDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxPostMeasDelay_Validating);
            // 
            // label73
            // 
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(5, 32);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(99, 34);
            this.label73.TabIndex = 43;
            this.label73.Text = "Post Meas. Delay (s)";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // checkBoxEnablePostMeas
            // 
            this.checkBoxEnablePostMeas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxEnablePostMeas.Location = new System.Drawing.Point(6, 13);
            this.checkBoxEnablePostMeas.Name = "checkBoxEnablePostMeas";
            this.checkBoxEnablePostMeas.Size = new System.Drawing.Size(92, 22);
            this.checkBoxEnablePostMeas.TabIndex = 0;
            this.checkBoxEnablePostMeas.Text = "Enable";
            // 
            // comboBoxMeasIntervalMode
            // 
            this.comboBoxMeasIntervalMode.FormattingEnabled = true;
            this.comboBoxMeasIntervalMode.Items.AddRange(new object[] {
            "LINEAR",
            "LOG10",
            "LOG25"});
            this.comboBoxMeasIntervalMode.Location = new System.Drawing.Point(90, 91);
            this.comboBoxMeasIntervalMode.Name = "comboBoxMeasIntervalMode";
            this.comboBoxMeasIntervalMode.Size = new System.Drawing.Size(77, 21);
            this.comboBoxMeasIntervalMode.TabIndex = 3;
            this.comboBoxMeasIntervalMode.SelectedIndexChanged += new System.EventHandler(this.MeasIntervalMode_SelectedIndexChanged);
            // 
            // label52
            // 
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(6, 88);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(87, 24);
            this.label52.TabIndex = 41;
            this.label52.Text = "Interval Mode";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxMeasIterationNumber
            // 
            this.textBoxMeasIterationNumber.Location = new System.Drawing.Point(112, 117);
            this.textBoxMeasIterationNumber.Name = "textBoxMeasIterationNumber";
            this.textBoxMeasIterationNumber.Size = new System.Drawing.Size(56, 20);
            this.textBoxMeasIterationNumber.TabIndex = 4;
            this.textBoxMeasIterationNumber.Text = "1";
            this.textBoxMeasIterationNumber.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxMeasIterationNumber_Validating);
            // 
            // textBoxIterativeMeasInterval
            // 
            this.textBoxIterativeMeasInterval.Location = new System.Drawing.Point(111, 66);
            this.textBoxIterativeMeasInterval.Name = "textBoxIterativeMeasInterval";
            this.textBoxIterativeMeasInterval.Size = new System.Drawing.Size(56, 20);
            this.textBoxIterativeMeasInterval.TabIndex = 2;
            this.textBoxIterativeMeasInterval.Text = "1E-6";
            this.textBoxIterativeMeasInterval.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxIterativeMeasInterval_Validating);
            // 
            // label50
            // 
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(7, 117);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(107, 20);
            this.label50.TabIndex = 3;
            this.label50.Text = "Iteration Number";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(6, 66);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(113, 19);
            this.label49.TabIndex = 3;
            this.label49.Text = "Initial Interval (s)";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label53
            // 
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(6, 15);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(88, 16);
            this.label53.TabIndex = 22;
            this.label53.Text = "dVg (V)";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label54
            // 
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(6, 46);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(88, 16);
            this.label54.TabIndex = 21;
            this.label54.Text = "Vd (V)";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label56
            // 
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(6, 107);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(88, 28);
            this.label56.TabIndex = 20;
            this.label56.Text = "MeasurementDelay (s)";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label55
            // 
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(6, 142);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(88, 35);
            this.label55.TabIndex = 23;
            this.label55.Text = "Averaging Time (s)";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label57
            // 
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(6, 76);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(88, 16);
            this.label57.TabIndex = 19;
            this.label57.Text = "Edge (s)";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSweepVdPulseBase
            // 
            this.textBoxSweepVdPulseBase.Location = new System.Drawing.Point(99, 48);
            this.textBoxSweepVdPulseBase.Name = "textBoxSweepVdPulseBase";
            this.textBoxSweepVdPulseBase.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepVdPulseBase.TabIndex = 1;
            this.textBoxSweepVdPulseBase.Text = "0.0";
            this.textBoxSweepVdPulseBase.TextChanged += new System.EventHandler(this.textBoxSweepVdPulseBase_TextChanged);
            this.textBoxSweepVdPulseBase.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepVdPulseBase_Validating);
            // 
            // textBoxOTFMeasDelay
            // 
            this.textBoxOTFMeasDelay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxOTFMeasDelay.Location = new System.Drawing.Point(113, 110);
            this.textBoxOTFMeasDelay.Name = "textBoxOTFMeasDelay";
            this.textBoxOTFMeasDelay.Size = new System.Drawing.Size(56, 22);
            this.textBoxOTFMeasDelay.TabIndex = 3;
            this.textBoxOTFMeasDelay.Text = "20E-9";
            this.textBoxOTFMeasDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxOTFMeasDelay_Validating);
            // 
            // label40
            // 
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(5, 48);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(88, 16);
            this.label40.TabIndex = 3;
            this.label40.Text = "Base (V)";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSweepVdPulseWidth
            // 
            this.textBoxSweepVdPulseWidth.Location = new System.Drawing.Point(99, 72);
            this.textBoxSweepVdPulseWidth.Name = "textBoxSweepVdPulseWidth";
            this.textBoxSweepVdPulseWidth.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepVdPulseWidth.TabIndex = 2;
            this.textBoxSweepVdPulseWidth.Text = "1E-6";
            this.textBoxSweepVdPulseWidth.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepVdPulseWidth_Validating);
            // 
            // textBoxOTFdVg
            // 
            this.textBoxOTFdVg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxOTFdVg.Location = new System.Drawing.Point(113, 15);
            this.textBoxOTFdVg.Name = "textBoxOTFdVg";
            this.textBoxOTFdVg.Size = new System.Drawing.Size(56, 22);
            this.textBoxOTFdVg.TabIndex = 0;
            this.textBoxOTFdVg.Text = "0.1";
            this.textBoxOTFdVg.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxOTFdVg_Validating);
            // 
            // textBoxOTFVd
            // 
            this.textBoxOTFVd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxOTFVd.Location = new System.Drawing.Point(113, 46);
            this.textBoxOTFVd.Name = "textBoxOTFVd";
            this.textBoxOTFVd.Size = new System.Drawing.Size(56, 22);
            this.textBoxOTFVd.TabIndex = 1;
            this.textBoxOTFVd.Text = "0";
            this.textBoxOTFVd.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxOTFVd_Validating);
            // 
            // buttonLoad
            // 
            this.buttonLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLoad.Location = new System.Drawing.Point(332, 470);
            this.buttonLoad.Name = "buttonLoad";
            this.buttonLoad.Size = new System.Drawing.Size(72, 41);
            this.buttonLoad.TabIndex = 6;
            this.buttonLoad.Text = "Re-Load Setup";
            this.buttonLoad.Click += new System.EventHandler(this.buttonLoad_Click);
            // 
            // textBoxOTFMeasAveragingTime
            // 
            this.textBoxOTFMeasAveragingTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxOTFMeasAveragingTime.Location = new System.Drawing.Point(113, 148);
            this.textBoxOTFMeasAveragingTime.Name = "textBoxOTFMeasAveragingTime";
            this.textBoxOTFMeasAveragingTime.Size = new System.Drawing.Size(56, 22);
            this.textBoxOTFMeasAveragingTime.TabIndex = 4;
            this.textBoxOTFMeasAveragingTime.Text = "10E-9";
            this.textBoxOTFMeasAveragingTime.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxOTFMeasAveragingTime_Validating);
            // 
            // buttonExecMeas
            // 
            this.buttonExecMeas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExecMeas.Location = new System.Drawing.Point(118, 470);
            this.buttonExecMeas.Name = "buttonExecMeas";
            this.buttonExecMeas.Size = new System.Drawing.Size(75, 41);
            this.buttonExecMeas.TabIndex = 4;
            this.buttonExecMeas.Text = "Execute";
            this.buttonExecMeas.Click += new System.EventHandler(this.buttonExecMeas_Click);
            // 
            // textBoxOTFEdge
            // 
            this.textBoxOTFEdge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxOTFEdge.Location = new System.Drawing.Point(113, 76);
            this.textBoxOTFEdge.Name = "textBoxOTFEdge";
            this.textBoxOTFEdge.Size = new System.Drawing.Size(56, 22);
            this.textBoxOTFEdge.TabIndex = 2;
            this.textBoxOTFEdge.Text = "100E-9";
            this.textBoxOTFEdge.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxOTFEdge_Validating);
            // 
            // validPattern
            // 
            this.validPattern.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validPattern.Location = new System.Drawing.Point(10, 470);
            this.validPattern.Name = "validPattern";
            this.validPattern.Size = new System.Drawing.Size(75, 41);
            this.validPattern.TabIndex = 3;
            this.validPattern.Text = "Validate Pattern";
            this.validPattern.Click += new System.EventHandler(this.validPattern_Click);
            // 
            // label41
            // 
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(5, 72);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(88, 16);
            this.label41.TabIndex = 3;
            this.label41.Text = "Width (s)";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // buttonClose
            // 
            this.buttonClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClose.Location = new System.Drawing.Point(547, 470);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(72, 41);
            this.buttonClose.TabIndex = 8;
            this.buttonClose.Text = "Close";
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // textBoxSweepPulsePeriod
            // 
            this.textBoxSweepPulsePeriod.Location = new System.Drawing.Point(104, 43);
            this.textBoxSweepPulsePeriod.Name = "textBoxSweepPulsePeriod";
            this.textBoxSweepPulsePeriod.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepPulsePeriod.TabIndex = 1;
            this.textBoxSweepPulsePeriod.Text = "2E-6";
            this.textBoxSweepPulsePeriod.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepPulsePeriod_Validating);
            // 
            // textBoxSweepVgPulseBase
            // 
            this.textBoxSweepVgPulseBase.Location = new System.Drawing.Point(104, 19);
            this.textBoxSweepVgPulseBase.Name = "textBoxSweepVgPulseBase";
            this.textBoxSweepVgPulseBase.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepVgPulseBase.TabIndex = 0;
            this.textBoxSweepVgPulseBase.Text = "0";
            this.textBoxSweepVgPulseBase.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepVgPulseBase_Validating);
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(6, 19);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(88, 16);
            this.label26.TabIndex = 3;
            this.label26.Text = "Base (V)";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Labelx2
            // 
            this.Labelx2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Labelx2.Location = new System.Drawing.Point(6, 43);
            this.Labelx2.Name = "Labelx2";
            this.Labelx2.Size = new System.Drawing.Size(72, 21);
            this.Labelx2.TabIndex = 3;
            this.Labelx2.Text = "Period (s)";
            this.Labelx2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Labelx4
            // 
            this.Labelx4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Labelx4.Location = new System.Drawing.Point(6, 95);
            this.Labelx4.Name = "Labelx4";
            this.Labelx4.Size = new System.Drawing.Size(88, 40);
            this.Labelx4.TabIndex = 3;
            this.Labelx4.Text = "Rise/Fall Time (s)";
            this.Labelx4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Labelx3
            // 
            this.Labelx3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Labelx3.Location = new System.Drawing.Point(6, 69);
            this.Labelx3.Name = "Labelx3";
            this.Labelx3.Size = new System.Drawing.Size(64, 16);
            this.Labelx3.TabIndex = 3;
            this.Labelx3.Text = "Width (s)";
            this.Labelx3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSweepVdPulseDelay
            // 
            this.textBoxSweepVdPulseDelay.Location = new System.Drawing.Point(99, 138);
            this.textBoxSweepVdPulseDelay.Name = "textBoxSweepVdPulseDelay";
            this.textBoxSweepVdPulseDelay.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepVdPulseDelay.TabIndex = 4;
            this.textBoxSweepVdPulseDelay.Text = "0.0";
            this.textBoxSweepVdPulseDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepVdPulseDelay_Validating);
            // 
            // checkBoxDualSweep
            // 
            this.checkBoxDualSweep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxDualSweep.Location = new System.Drawing.Point(10, 6);
            this.checkBoxDualSweep.Name = "checkBoxDualSweep";
            this.checkBoxDualSweep.Size = new System.Drawing.Size(106, 30);
            this.checkBoxDualSweep.TabIndex = 0;
            this.checkBoxDualSweep.Text = "Dual Sweep";
            // 
            // groupSweepVgPulse
            // 
            this.groupSweepVgPulse.Controls.Add(this.textBoxSweepPulsePeriod);
            this.groupSweepVgPulse.Controls.Add(this.textBoxSweepVgPulseBase);
            this.groupSweepVgPulse.Controls.Add(this.label26);
            this.groupSweepVgPulse.Controls.Add(this.Labelx2);
            this.groupSweepVgPulse.Controls.Add(this.Labelx3);
            this.groupSweepVgPulse.Controls.Add(this.Labelx4);
            this.groupSweepVgPulse.Controls.Add(Labelx6);
            this.groupSweepVgPulse.Controls.Add(this.textBoxSweepVgPulseWidth);
            this.groupSweepVgPulse.Controls.Add(this.textBoxSweepVgPulseLeadingEdge);
            this.groupSweepVgPulse.Controls.Add(this.textBoxSweepVgPulseDelay);
            this.groupSweepVgPulse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupSweepVgPulse.Location = new System.Drawing.Point(6, 6);
            this.groupSweepVgPulse.Name = "groupSweepVgPulse";
            this.groupSweepVgPulse.Size = new System.Drawing.Size(193, 171);
            this.groupSweepVgPulse.TabIndex = 0;
            this.groupSweepVgPulse.TabStop = false;
            this.groupSweepVgPulse.Text = "Vg";
            // 
            // textBoxSweepVgPulseWidth
            // 
            this.textBoxSweepVgPulseWidth.Location = new System.Drawing.Point(105, 69);
            this.textBoxSweepVgPulseWidth.Name = "textBoxSweepVgPulseWidth";
            this.textBoxSweepVgPulseWidth.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepVgPulseWidth.TabIndex = 2;
            this.textBoxSweepVgPulseWidth.Text = "1E-6";
            this.textBoxSweepVgPulseWidth.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepVgPulseWidth_Validating);
            // 
            // textBoxSweepVgPulseLeadingEdge
            // 
            this.textBoxSweepVgPulseLeadingEdge.Location = new System.Drawing.Point(104, 106);
            this.textBoxSweepVgPulseLeadingEdge.Name = "textBoxSweepVgPulseLeadingEdge";
            this.textBoxSweepVgPulseLeadingEdge.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepVgPulseLeadingEdge.TabIndex = 3;
            this.textBoxSweepVgPulseLeadingEdge.Text = "100E-9";
            this.textBoxSweepVgPulseLeadingEdge.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepVgPulseLeadingEdge_Validating);
            // 
            // textBoxSweepVgPulseDelay
            // 
            this.textBoxSweepVgPulseDelay.Location = new System.Drawing.Point(104, 141);
            this.textBoxSweepVgPulseDelay.Name = "textBoxSweepVgPulseDelay";
            this.textBoxSweepVgPulseDelay.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepVgPulseDelay.TabIndex = 4;
            this.textBoxSweepVgPulseDelay.Text = "0.0";
            this.textBoxSweepVgPulseDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepVgPulseDelay_Validating);
            // 
            // label43
            // 
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(5, 133);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(64, 29);
            this.label43.TabIndex = 3;
            this.label43.Text = "Pulse Delay (s)";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // checkBoxSweepVdPulse
            // 
            this.checkBoxSweepVdPulse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSweepVdPulse.Location = new System.Drawing.Point(8, 19);
            this.checkBoxSweepVdPulse.Name = "checkBoxSweepVdPulse";
            this.checkBoxSweepVdPulse.Size = new System.Drawing.Size(152, 24);
            this.checkBoxSweepVdPulse.TabIndex = 0;
            this.checkBoxSweepVdPulse.Text = "Enable Pulse Bias";
            // 
            // groupSweepVdPulse
            // 
            this.groupSweepVdPulse.Controls.Add(this.label27);
            this.groupSweepVdPulse.Controls.Add(this.checkBoxSweepVdPulse);
            this.groupSweepVdPulse.Controls.Add(this.textBoxSweepVdPulseBase);
            this.groupSweepVdPulse.Controls.Add(this.label40);
            this.groupSweepVdPulse.Controls.Add(this.textBoxSweepVdPulseWidth);
            this.groupSweepVdPulse.Controls.Add(this.label41);
            this.groupSweepVdPulse.Controls.Add(this.textBoxSweepVdPulseDelay);
            this.groupSweepVdPulse.Controls.Add(this.textBoxSweepVdPulseLeadingEdge);
            this.groupSweepVdPulse.Controls.Add(this.label43);
            this.groupSweepVdPulse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupSweepVdPulse.Location = new System.Drawing.Point(6, 198);
            this.groupSweepVdPulse.Name = "groupSweepVdPulse";
            this.groupSweepVdPulse.Size = new System.Drawing.Size(193, 193);
            this.groupSweepVdPulse.TabIndex = 1;
            this.groupSweepVdPulse.TabStop = false;
            this.groupSweepVdPulse.Text = "Vd";
            // 
            // label27
            // 
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(5, 93);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(88, 40);
            this.label27.TabIndex = 6;
            this.label27.Text = "Rise/Fall Time (s)";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSweepVdPulseLeadingEdge
            // 
            this.textBoxSweepVdPulseLeadingEdge.Location = new System.Drawing.Point(99, 104);
            this.textBoxSweepVdPulseLeadingEdge.Name = "textBoxSweepVdPulseLeadingEdge";
            this.textBoxSweepVdPulseLeadingEdge.Size = new System.Drawing.Size(56, 20);
            this.textBoxSweepVdPulseLeadingEdge.TabIndex = 3;
            this.textBoxSweepVdPulseLeadingEdge.Text = "100E-9";
            this.textBoxSweepVdPulseLeadingEdge.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSweepVdPulseLeadingEdge_Validating);
            // 
            // tabSamplingSetup
            // 
            this.tabSamplingSetup.Controls.Add(this.label39);
            this.tabSamplingSetup.Controls.Add(this.textBoxSamplingExtraDelay);
            this.tabSamplingSetup.Controls.Add(this.comboBoxSamplingMode);
            this.tabSamplingSetup.Controls.Add(this.label60);
            this.tabSamplingSetup.Controls.Add(this.label13);
            this.tabSamplingSetup.Controls.Add(this.label14);
            this.tabSamplingSetup.Controls.Add(this.label16);
            this.tabSamplingSetup.Controls.Add(this.label18);
            this.tabSamplingSetup.Controls.Add(this.label17);
            this.tabSamplingSetup.Controls.Add(this.label34);
            this.tabSamplingSetup.Controls.Add(this.label35);
            this.tabSamplingSetup.Controls.Add(this.textBoxSamplingMeasDelay);
            this.tabSamplingSetup.Controls.Add(this.textBoxSamplingVg);
            this.tabSamplingSetup.Controls.Add(this.textBoxSamplingVd);
            this.tabSamplingSetup.Controls.Add(this.textBoxSampingMeasPoints);
            this.tabSamplingSetup.Controls.Add(this.textBoxSamplingMeasInterval);
            this.tabSamplingSetup.Controls.Add(this.textBoxSamplingHold);
            this.tabSamplingSetup.Controls.Add(this.textBoxSamplingMeasAveragingTime);
            this.tabSamplingSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabSamplingSetup.Location = new System.Drawing.Point(4, 22);
            this.tabSamplingSetup.Name = "tabSamplingSetup";
            this.tabSamplingSetup.Padding = new System.Windows.Forms.Padding(3);
            this.tabSamplingSetup.Size = new System.Drawing.Size(205, 405);
            this.tabSamplingSetup.TabIndex = 0;
            this.tabSamplingSetup.Text = "Id Sampling";
            this.tabSamplingSetup.UseVisualStyleBackColor = true;
            // 
            // label39
            // 
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(3, 270);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(94, 34);
            this.label39.TabIndex = 18;
            this.label39.Text = " Extra Delay (s)";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxSamplingExtraDelay
            // 
            this.textBoxSamplingExtraDelay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSamplingExtraDelay.Location = new System.Drawing.Point(117, 276);
            this.textBoxSamplingExtraDelay.Name = "textBoxSamplingExtraDelay";
            this.textBoxSamplingExtraDelay.Size = new System.Drawing.Size(56, 22);
            this.textBoxSamplingExtraDelay.TabIndex = 8;
            this.textBoxSamplingExtraDelay.Text = "0";
            this.textBoxSamplingExtraDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSamplingExtraDelay_Validating);
            // 
            // label33
            // 
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(6, 100);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(120, 17);
            this.label33.TabIndex = 27;
            this.label33.Text = "Measurement Mode";
            // 
            // label46
            // 
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(3, 288);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(94, 22);
            this.label46.TabIndex = 29;
            this.label46.Text = "HW Skew (s)";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(6, 56);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(120, 17);
            this.label47.TabIndex = 28;
            this.label47.Text = "Operation Mode";
            // 
            // comboBoxGateChVMeasRange
            // 
            this.comboBoxGateChVMeasRange.FormattingEnabled = true;
            this.comboBoxGateChVMeasRange.Items.AddRange(new object[] {
            "+/-5 V",
            "+/- 10V"});
            this.comboBoxGateChVMeasRange.Location = new System.Drawing.Point(19, 263);
            this.comboBoxGateChVMeasRange.Name = "comboBoxGateChVMeasRange";
            this.comboBoxGateChVMeasRange.Size = new System.Drawing.Size(127, 21);
            this.comboBoxGateChVMeasRange.TabIndex = 6;
            // 
            // checkBoxDrainMeas
            // 
            this.checkBoxDrainMeas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxDrainMeas.Location = new System.Drawing.Point(6, 13);
            this.checkBoxDrainMeas.Name = "checkBoxDrainMeas";
            this.checkBoxDrainMeas.Size = new System.Drawing.Size(120, 18);
            this.checkBoxDrainMeas.TabIndex = 0;
            this.checkBoxDrainMeas.Text = "Measurement";
            // 
            // label48
            // 
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(6, 234);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(149, 29);
            this.label48.TabIndex = 24;
            this.label48.Text = "Voltage Measurement Range";
            // 
            // comboBoxGateChForceRange
            // 
            this.comboBoxGateChForceRange.FormattingEnabled = true;
            this.comboBoxGateChForceRange.Items.AddRange(new object[] {
            "+/-5 V",
            "-10 V to 0 V",
            "0 V to +10 V"});
            this.comboBoxGateChForceRange.Location = new System.Drawing.Point(19, 158);
            this.comboBoxGateChForceRange.Name = "comboBoxGateChForceRange";
            this.comboBoxGateChForceRange.Size = new System.Drawing.Size(127, 21);
            this.comboBoxGateChForceRange.TabIndex = 4;
            // 
            // label51
            // 
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(6, 141);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(130, 18);
            this.label51.TabIndex = 25;
            this.label51.Text = "Voltage Force Range";
            // 
            // comboBoxGateChMeasMode
            // 
            this.comboBoxGateChMeasMode.FormattingEnabled = true;
            this.comboBoxGateChMeasMode.Items.AddRange(new object[] {
            "V measure mode",
            "I measure mode"});
            this.comboBoxGateChMeasMode.Location = new System.Drawing.Point(19, 117);
            this.comboBoxGateChMeasMode.Name = "comboBoxGateChMeasMode";
            this.comboBoxGateChMeasMode.Size = new System.Drawing.Size(127, 21);
            this.comboBoxGateChMeasMode.TabIndex = 3;
            this.comboBoxGateChMeasMode.SelectedIndexChanged += new System.EventHandler(this.comboGateChMeasMode_SelectedIndexChanged);
            // 
            // comboBoxGateChOperationMode
            // 
            this.comboBoxGateChOperationMode.FormattingEnabled = true;
            this.comboBoxGateChOperationMode.Items.AddRange(new object[] {
            "Fast IV mode",
            "PG Mode"});
            this.comboBoxGateChOperationMode.Location = new System.Drawing.Point(19, 76);
            this.comboBoxGateChOperationMode.Name = "comboBoxGateChOperationMode";
            this.comboBoxGateChOperationMode.Size = new System.Drawing.Size(127, 21);
            this.comboBoxGateChOperationMode.TabIndex = 2;
            this.comboBoxGateChOperationMode.SelectedIndexChanged += new System.EventHandler(this.comboBoxGateChOperationMode_SelectedIndexChanged);
            // 
            // tabStressSetup
            // 
            this.tabStressSetup.Controls.Add(this.tabAccStressTimeSetup);
            this.tabStressSetup.Controls.Add(this.tabStressVgSetup);
            this.tabStressSetup.Controls.Add(this.tabStressVdSetup);
            this.tabStressSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabStressSetup.Location = new System.Drawing.Point(185, 31);
            this.tabStressSetup.Name = "tabStressSetup";
            this.tabStressSetup.SelectedIndex = 0;
            this.tabStressSetup.Size = new System.Drawing.Size(219, 433);
            this.tabStressSetup.TabIndex = 1;
            // 
            // tabAccStressTimeSetup
            // 
            this.tabAccStressTimeSetup.Controls.Add(this.dataViewStressList);
            this.tabAccStressTimeSetup.Location = new System.Drawing.Point(4, 22);
            this.tabAccStressTimeSetup.Name = "tabAccStressTimeSetup";
            this.tabAccStressTimeSetup.Padding = new System.Windows.Forms.Padding(3);
            this.tabAccStressTimeSetup.Size = new System.Drawing.Size(211, 407);
            this.tabAccStressTimeSetup.TabIndex = 2;
            this.tabAccStressTimeSetup.Text = "Stress Time";
            this.tabAccStressTimeSetup.UseVisualStyleBackColor = true;
            // 
            // dataViewStressList
            // 
            this.dataViewStressList.AllowUserToAddRows = false;
            this.dataViewStressList.AllowUserToDeleteRows = false;
            this.dataViewStressList.AllowUserToResizeColumns = false;
            this.dataViewStressList.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataViewStressList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataViewStressList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataViewStressList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.StressNum,
            this.ListAccumulatedStressTime});
            this.dataViewStressList.Location = new System.Drawing.Point(9, 13);
            this.dataViewStressList.MultiSelect = false;
            this.dataViewStressList.Name = "dataViewStressList";
            this.dataViewStressList.RowHeadersVisible = false;
            this.dataViewStressList.Size = new System.Drawing.Size(172, 378);
            this.dataViewStressList.TabIndex = 0;
            this.dataViewStressList.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dataViewStressList_CellValidating);
            this.dataViewStressList.CurrentCellDirtyStateChanged += new System.EventHandler(this.dataViewStressList_CurrentCellDirtyStateChanged);
            // 
            // StressNum
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StressNum.DefaultCellStyle = dataGridViewCellStyle2;
            this.StressNum.HeaderText = "No.";
            this.StressNum.Name = "StressNum";
            this.StressNum.ReadOnly = true;
            this.StressNum.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.StressNum.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.StressNum.Width = 35;
            // 
            // ListAccumulatedStressTime
            // 
            this.ListAccumulatedStressTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListAccumulatedStressTime.DefaultCellStyle = dataGridViewCellStyle3;
            this.ListAccumulatedStressTime.FillWeight = 90F;
            this.ListAccumulatedStressTime.HeaderText = "Accumulated Stress Time (s)";
            this.ListAccumulatedStressTime.Name = "ListAccumulatedStressTime";
            this.ListAccumulatedStressTime.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ListAccumulatedStressTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ListAccumulatedStressTime.Width = 116;
            // 
            // tabStressVgSetup
            // 
            this.tabStressVgSetup.Controls.Add(this.groupBox9);
            this.tabStressVgSetup.Controls.Add(this.groupBox8);
            this.tabStressVgSetup.Controls.Add(this.groupACStressVgPulse);
            this.tabStressVgSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabStressVgSetup.Location = new System.Drawing.Point(4, 22);
            this.tabStressVgSetup.Name = "tabStressVgSetup";
            this.tabStressVgSetup.Padding = new System.Windows.Forms.Padding(3);
            this.tabStressVgSetup.Size = new System.Drawing.Size(211, 407);
            this.tabStressVgSetup.TabIndex = 0;
            this.tabStressVgSetup.Text = "Vg";
            this.tabStressVgSetup.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.textBoxVgRangeChangeHold);
            this.groupBox9.Controls.Add(this.label77);
            this.groupBox9.Controls.Add(this.comboBoxVgStressCurrentRange);
            this.groupBox9.Controls.Add(this.label74);
            this.groupBox9.Controls.Add(this.label4);
            this.groupBox9.Controls.Add(this.textBoxStressVg);
            this.groupBox9.Location = new System.Drawing.Point(10, 75);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(195, 118);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Bias";
            // 
            // textBoxVgRangeChangeHold
            // 
            this.textBoxVgRangeChangeHold.Location = new System.Drawing.Point(121, 91);
            this.textBoxVgRangeChangeHold.Name = "textBoxVgRangeChangeHold";
            this.textBoxVgRangeChangeHold.Size = new System.Drawing.Size(56, 20);
            this.textBoxVgRangeChangeHold.TabIndex = 2;
            this.textBoxVgRangeChangeHold.Text = "0.0";
            this.textBoxVgRangeChangeHold.TextChanged += new System.EventHandler(this.textBoxVgRangeChangeHold_TextChanged);
            this.textBoxVgRangeChangeHold.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxVgRangeChangeHold_Validating);
            // 
            // label77
            // 
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(16, 86);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(99, 29);
            this.label77.TabIndex = 27;
            this.label77.Text = "Range Change Hold (s)";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBoxVgStressCurrentRange
            // 
            this.comboBoxVgStressCurrentRange.FormattingEnabled = true;
            this.comboBoxVgStressCurrentRange.Items.AddRange(new object[] {
            "+/-1 uA Fixed",
            "+/-10 uA Fixed",
            "+/-100 uA Fixed",
            "+/-1 mA Fixed",
            "+/-10 mA Fixed"});
            this.comboBoxVgStressCurrentRange.Location = new System.Drawing.Point(50, 58);
            this.comboBoxVgStressCurrentRange.Name = "comboBoxVgStressCurrentRange";
            this.comboBoxVgStressCurrentRange.Size = new System.Drawing.Size(127, 21);
            this.comboBoxVgStressCurrentRange.TabIndex = 1;
            // 
            // label74
            // 
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(16, 39);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(140, 17);
            this.label74.TabIndex = 25;
            this.label74.Text = "Current Range";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Vg Stress (V)";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxStressVg
            // 
            this.textBoxStressVg.Location = new System.Drawing.Point(121, 16);
            this.textBoxStressVg.Name = "textBoxStressVg";
            this.textBoxStressVg.Size = new System.Drawing.Size(56, 20);
            this.textBoxStressVg.TabIndex = 0;
            this.textBoxStressVg.Text = "0.0";
            this.textBoxStressVg.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressVg_Validating);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.radioButtonPulseStress);
            this.groupBox8.Controls.Add(this.radioButtonDCStress);
            this.groupBox8.Location = new System.Drawing.Point(6, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(199, 63);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Stress Type";
            // 
            // radioButtonPulseStress
            // 
            this.radioButtonPulseStress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonPulseStress.Location = new System.Drawing.Point(15, 41);
            this.radioButtonPulseStress.Name = "radioButtonPulseStress";
            this.radioButtonPulseStress.Size = new System.Drawing.Size(104, 16);
            this.radioButtonPulseStress.TabIndex = 1;
            this.radioButtonPulseStress.Text = "AC Stress";
            this.radioButtonPulseStress.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.radioButtonPulseStress.CheckedChanged += new System.EventHandler(this.radioButtonPulseStress_CheckedChanged);
            // 
            // radioButtonDCStress
            // 
            this.radioButtonDCStress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDCStress.Location = new System.Drawing.Point(15, 19);
            this.radioButtonDCStress.Name = "radioButtonDCStress";
            this.radioButtonDCStress.Size = new System.Drawing.Size(104, 16);
            this.radioButtonDCStress.TabIndex = 0;
            this.radioButtonDCStress.Text = "DC Stress";
            // 
            // groupACStressVgPulse
            // 
            this.groupACStressVgPulse.Controls.Add(this.label9);
            this.groupACStressVgPulse.Controls.Add(this.comboBoxStressPulseFreq);
            this.groupACStressVgPulse.Controls.Add(this.textBoxStressVgBase);
            this.groupACStressVgPulse.Controls.Add(this.label6);
            this.groupACStressVgPulse.Controls.Add(this.label7);
            this.groupACStressVgPulse.Controls.Add(this.label8);
            this.groupACStressVgPulse.Controls.Add(this.label11);
            this.groupACStressVgPulse.Controls.Add(this.textBoxStressVgPulseDuty);
            this.groupACStressVgPulse.Controls.Add(this.textBoxStressVgPulseLeadingEdge);
            this.groupACStressVgPulse.Controls.Add(this.textBoxStressVgPulseDelay);
            this.groupACStressVgPulse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupACStressVgPulse.Location = new System.Drawing.Point(10, 199);
            this.groupACStressVgPulse.Name = "groupACStressVgPulse";
            this.groupACStressVgPulse.Size = new System.Drawing.Size(195, 202);
            this.groupACStressVgPulse.TabIndex = 2;
            this.groupACStressVgPulse.TabStop = false;
            this.groupACStressVgPulse.Text = "Pulse";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(9, 121);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 40);
            this.label9.TabIndex = 25;
            this.label9.Text = "Rise/Fall Time (s)";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBoxStressPulseFreq
            // 
            this.comboBoxStressPulseFreq.FormattingEnabled = true;
            this.comboBoxStressPulseFreq.Items.AddRange(new object[] {
            "100 Hz",
            "1k Hz",
            "10k Hz",
            "100k Hz",
            "1M Hz",
            "2M Hz",
            "5M Hz"});
            this.comboBoxStressPulseFreq.Location = new System.Drawing.Point(80, 64);
            this.comboBoxStressPulseFreq.Name = "comboBoxStressPulseFreq";
            this.comboBoxStressPulseFreq.Size = new System.Drawing.Size(84, 21);
            this.comboBoxStressPulseFreq.TabIndex = 1;
            this.comboBoxStressPulseFreq.SelectedIndexChanged += new System.EventHandler(this.comboStressPulseFreq_SelectedIndexChanged);
            // 
            // textBoxStressVgBase
            // 
            this.textBoxStressVgBase.Location = new System.Drawing.Point(108, 33);
            this.textBoxStressVgBase.Name = "textBoxStressVgBase";
            this.textBoxStressVgBase.Size = new System.Drawing.Size(56, 20);
            this.textBoxStressVgBase.TabIndex = 0;
            this.textBoxStressVgBase.Text = "0.0";
            this.textBoxStressVgBase.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressVgBase_Validating);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(9, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 16);
            this.label6.TabIndex = 3;
            this.label6.Text = "Vg Base (V)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(9, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 32);
            this.label7.TabIndex = 3;
            this.label7.Text = "Frequency (Hz)";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(9, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 16);
            this.label8.TabIndex = 3;
            this.label8.Text = "Duty (%)";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 167);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 16);
            this.label11.TabIndex = 3;
            this.label11.Text = "Delay (sec)";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxStressVgPulseDuty
            // 
            this.textBoxStressVgPulseDuty.Location = new System.Drawing.Point(108, 97);
            this.textBoxStressVgPulseDuty.Name = "textBoxStressVgPulseDuty";
            this.textBoxStressVgPulseDuty.Size = new System.Drawing.Size(56, 20);
            this.textBoxStressVgPulseDuty.TabIndex = 2;
            this.textBoxStressVgPulseDuty.Text = "50";
            this.textBoxStressVgPulseDuty.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressVgPulseDuty_Validating);
            // 
            // textBoxStressVgPulseLeadingEdge
            // 
            this.textBoxStressVgPulseLeadingEdge.Location = new System.Drawing.Point(108, 132);
            this.textBoxStressVgPulseLeadingEdge.Name = "textBoxStressVgPulseLeadingEdge";
            this.textBoxStressVgPulseLeadingEdge.Size = new System.Drawing.Size(56, 20);
            this.textBoxStressVgPulseLeadingEdge.TabIndex = 3;
            this.textBoxStressVgPulseLeadingEdge.Text = "100E-9";
            this.textBoxStressVgPulseLeadingEdge.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressVgPulseLeadingEdge_Validating);
            // 
            // textBoxStressVgPulseDelay
            // 
            this.textBoxStressVgPulseDelay.Location = new System.Drawing.Point(108, 167);
            this.textBoxStressVgPulseDelay.Name = "textBoxStressVgPulseDelay";
            this.textBoxStressVgPulseDelay.Size = new System.Drawing.Size(56, 20);
            this.textBoxStressVgPulseDelay.TabIndex = 4;
            this.textBoxStressVgPulseDelay.Text = "0.0";
            this.textBoxStressVgPulseDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressVgPulseDelay_Validating);
            // 
            // tabStressVdSetup
            // 
            this.tabStressVdSetup.Controls.Add(this.groupBox10);
            this.tabStressVdSetup.Controls.Add(this.groupVdACStress);
            this.tabStressVdSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabStressVdSetup.Location = new System.Drawing.Point(4, 22);
            this.tabStressVdSetup.Name = "tabStressVdSetup";
            this.tabStressVdSetup.Padding = new System.Windows.Forms.Padding(3);
            this.tabStressVdSetup.Size = new System.Drawing.Size(211, 407);
            this.tabStressVdSetup.TabIndex = 1;
            this.tabStressVdSetup.Text = "Vd";
            this.tabStressVdSetup.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.textBoxVdRangeChangeHold);
            this.groupBox10.Controls.Add(this.label76);
            this.groupBox10.Controls.Add(this.label12);
            this.groupBox10.Controls.Add(this.comboBoxVdStressCurrentRange);
            this.groupBox10.Controls.Add(this.textBoxStressVd);
            this.groupBox10.Controls.Add(this.label75);
            this.groupBox10.Location = new System.Drawing.Point(9, 13);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(196, 130);
            this.groupBox10.TabIndex = 0;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Bias";
            // 
            // textBoxVdRangeChangeHold
            // 
            this.textBoxVdRangeChangeHold.Location = new System.Drawing.Point(111, 101);
            this.textBoxVdRangeChangeHold.Name = "textBoxVdRangeChangeHold";
            this.textBoxVdRangeChangeHold.Size = new System.Drawing.Size(56, 20);
            this.textBoxVdRangeChangeHold.TabIndex = 2;
            this.textBoxVdRangeChangeHold.Text = "0.0";
            this.textBoxVdRangeChangeHold.TextChanged += new System.EventHandler(this.textBoxVdRangeChangeHold_TextChanged);
            this.textBoxVdRangeChangeHold.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxVdRangeChangeHold_Validating);
            // 
            // label76
            // 
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(6, 96);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(99, 29);
            this.label76.TabIndex = 3;
            this.label76.Text = "Range Change Hold (s)";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 16);
            this.label12.TabIndex = 3;
            this.label12.Text = "Vd Stress (V)";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBoxVdStressCurrentRange
            // 
            this.comboBoxVdStressCurrentRange.FormattingEnabled = true;
            this.comboBoxVdStressCurrentRange.Items.AddRange(new object[] {
            "+/-1 uA Fixed",
            "+/-10 uA Fixed",
            "+/-100 uA Fixed",
            "+/-1 mA Fixed",
            "+/-10 mA Fixed"});
            this.comboBoxVdStressCurrentRange.Location = new System.Drawing.Point(40, 67);
            this.comboBoxVdStressCurrentRange.Name = "comboBoxVdStressCurrentRange";
            this.comboBoxVdStressCurrentRange.Size = new System.Drawing.Size(127, 21);
            this.comboBoxVdStressCurrentRange.TabIndex = 1;
            // 
            // textBoxStressVd
            // 
            this.textBoxStressVd.Location = new System.Drawing.Point(111, 25);
            this.textBoxStressVd.Name = "textBoxStressVd";
            this.textBoxStressVd.Size = new System.Drawing.Size(56, 20);
            this.textBoxStressVd.TabIndex = 0;
            this.textBoxStressVd.Text = "0.0";
            this.textBoxStressVd.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressVd_Validating);
            // 
            // label75
            // 
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(6, 47);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(140, 17);
            this.label75.TabIndex = 27;
            this.label75.Text = "Current Range";
            // 
            // groupVdACStress
            // 
            this.groupVdACStress.Controls.Add(this.label28);
            this.groupVdACStress.Controls.Add(this.checkBoxVdPulseStress);
            this.groupVdACStress.Controls.Add(this.textBoxStressVdPulseBase);
            this.groupVdACStress.Controls.Add(this.label37);
            this.groupVdACStress.Controls.Add(this.textBoxStressVdPulseDuty);
            this.groupVdACStress.Controls.Add(this.label38);
            this.groupVdACStress.Controls.Add(this.textBoxStressVdPulseLeadingEdge);
            this.groupVdACStress.Controls.Add(this.Labelx1);
            this.groupVdACStress.Controls.Add(this.textBoxStressVdPulseDelay);
            this.groupVdACStress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupVdACStress.Location = new System.Drawing.Point(9, 158);
            this.groupVdACStress.Name = "groupVdACStress";
            this.groupVdACStress.Size = new System.Drawing.Size(196, 167);
            this.groupVdACStress.TabIndex = 1;
            this.groupVdACStress.TabStop = false;
            this.groupVdACStress.Text = "Pulse";
            this.groupVdACStress.Enter += new System.EventHandler(this.groupVdACStress_Enter);
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(19, 95);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(64, 40);
            this.label28.TabIndex = 6;
            this.label28.Text = "Rise/Fall Time (s)";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // checkBoxVdPulseStress
            // 
            this.checkBoxVdPulseStress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxVdPulseStress.Location = new System.Drawing.Point(23, 22);
            this.checkBoxVdPulseStress.Name = "checkBoxVdPulseStress";
            this.checkBoxVdPulseStress.Size = new System.Drawing.Size(152, 24);
            this.checkBoxVdPulseStress.TabIndex = 0;
            this.checkBoxVdPulseStress.Text = "Enable Pulse Stress";
            // 
            // textBoxStressVdPulseBase
            // 
            this.textBoxStressVdPulseBase.Location = new System.Drawing.Point(121, 52);
            this.textBoxStressVdPulseBase.Name = "textBoxStressVdPulseBase";
            this.textBoxStressVdPulseBase.Size = new System.Drawing.Size(54, 20);
            this.textBoxStressVdPulseBase.TabIndex = 1;
            this.textBoxStressVdPulseBase.Text = "0.0";
            this.textBoxStressVdPulseBase.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressVdPulseBase_Validating);
            // 
            // label37
            // 
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(19, 55);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(86, 16);
            this.label37.TabIndex = 3;
            this.label37.Text = "Vd Base (V)";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxStressVdPulseDuty
            // 
            this.textBoxStressVdPulseDuty.Location = new System.Drawing.Point(121, 76);
            this.textBoxStressVdPulseDuty.Name = "textBoxStressVdPulseDuty";
            this.textBoxStressVdPulseDuty.Size = new System.Drawing.Size(54, 20);
            this.textBoxStressVdPulseDuty.TabIndex = 2;
            this.textBoxStressVdPulseDuty.Text = "50";
            this.textBoxStressVdPulseDuty.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressVdPulseDuty_Validating);
            // 
            // label38
            // 
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(19, 79);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(64, 16);
            this.label38.TabIndex = 3;
            this.label38.Text = "Duty (%)";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxStressVdPulseLeadingEdge
            // 
            this.textBoxStressVdPulseLeadingEdge.Location = new System.Drawing.Point(121, 103);
            this.textBoxStressVdPulseLeadingEdge.Name = "textBoxStressVdPulseLeadingEdge";
            this.textBoxStressVdPulseLeadingEdge.Size = new System.Drawing.Size(54, 20);
            this.textBoxStressVdPulseLeadingEdge.TabIndex = 3;
            this.textBoxStressVdPulseLeadingEdge.Text = "100E-9";
            this.textBoxStressVdPulseLeadingEdge.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressVdPulseLeadingEdge_Validating);
            // 
            // Labelx1
            // 
            this.Labelx1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Labelx1.Location = new System.Drawing.Point(19, 135);
            this.Labelx1.Name = "Labelx1";
            this.Labelx1.Size = new System.Drawing.Size(64, 16);
            this.Labelx1.TabIndex = 3;
            this.Labelx1.Text = "Delay (sec)";
            this.Labelx1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxStressVdPulseDelay
            // 
            this.textBoxStressVdPulseDelay.Location = new System.Drawing.Point(121, 135);
            this.textBoxStressVdPulseDelay.Name = "textBoxStressVdPulseDelay";
            this.textBoxStressVdPulseDelay.Size = new System.Drawing.Size(54, 20);
            this.textBoxStressVdPulseDelay.TabIndex = 4;
            this.textBoxStressVdPulseDelay.Text = "0.0";
            this.textBoxStressVdPulseDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStressVdPulseDelay_Validating);
            // 
            // textBoxGateChHwSkew
            // 
            this.textBoxGateChHwSkew.Location = new System.Drawing.Point(90, 290);
            this.textBoxGateChHwSkew.Name = "textBoxGateChHwSkew";
            this.textBoxGateChHwSkew.Size = new System.Drawing.Size(56, 20);
            this.textBoxGateChHwSkew.TabIndex = 7;
            this.textBoxGateChHwSkew.Text = "0.0";
            this.textBoxGateChHwSkew.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxGateChHwSkew_Validating);
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(6, 100);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(120, 17);
            this.label32.TabIndex = 18;
            this.label32.Text = "Measurement Mode";
            // 
            // tabPivSetup
            // 
            this.tabPivSetup.Controls.Add(this.groupSweepVgPulse);
            this.tabPivSetup.Controls.Add(this.groupSweepVdPulse);
            this.tabPivSetup.Location = new System.Drawing.Point(4, 22);
            this.tabPivSetup.Name = "tabPivSetup";
            this.tabPivSetup.Padding = new System.Windows.Forms.Padding(3);
            this.tabPivSetup.Size = new System.Drawing.Size(205, 405);
            this.tabPivSetup.TabIndex = 2;
            this.tabPivSetup.Text = "PIV";
            this.tabPivSetup.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 288);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 22);
            this.label3.TabIndex = 19;
            this.label3.Text = "HW Skew (s)";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 17);
            this.label5.TabIndex = 18;
            this.label5.Text = "Operation Mode";
            // 
            // checkBoxGateMeas
            // 
            this.checkBoxGateMeas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxGateMeas.Location = new System.Drawing.Point(6, 13);
            this.checkBoxGateMeas.Name = "checkBoxGateMeas";
            this.checkBoxGateMeas.Size = new System.Drawing.Size(120, 18);
            this.checkBoxGateMeas.TabIndex = 0;
            this.checkBoxGateMeas.Text = "Measurement";
            // 
            // textBoxDrainChHwSkew
            // 
            this.textBoxDrainChHwSkew.Location = new System.Drawing.Point(90, 290);
            this.textBoxDrainChHwSkew.Name = "textBoxDrainChHwSkew";
            this.textBoxDrainChHwSkew.Size = new System.Drawing.Size(56, 20);
            this.textBoxDrainChHwSkew.TabIndex = 7;
            this.textBoxDrainChHwSkew.Text = "0.0";
            this.textBoxDrainChHwSkew.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxDrainChHwSkew_Validating);
            // 
            // label45
            // 
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(6, 234);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(140, 29);
            this.label45.TabIndex = 15;
            this.label45.Text = "Voltage Measurement Range";
            // 
            // comboBoxDrainChOperationMode
            // 
            this.comboBoxDrainChOperationMode.FormattingEnabled = true;
            this.comboBoxDrainChOperationMode.Items.AddRange(new object[] {
            "Fast IV mode",
            "PG Mmode"});
            this.comboBoxDrainChOperationMode.Location = new System.Drawing.Point(19, 76);
            this.comboBoxDrainChOperationMode.Name = "comboBoxDrainChOperationMode";
            this.comboBoxDrainChOperationMode.Size = new System.Drawing.Size(127, 21);
            this.comboBoxDrainChOperationMode.TabIndex = 2;
            this.comboBoxDrainChOperationMode.SelectedIndexChanged += new System.EventHandler(this.comboBoxDrainOperationMode_SelectedIndexChanged);
            // 
            // comboBoxDrainChMeasMode
            // 
            this.comboBoxDrainChMeasMode.FormattingEnabled = true;
            this.comboBoxDrainChMeasMode.Items.AddRange(new object[] {
            "V measure mode",
            "I measure mode"});
            this.comboBoxDrainChMeasMode.Location = new System.Drawing.Point(19, 117);
            this.comboBoxDrainChMeasMode.Name = "comboBoxDrainChMeasMode";
            this.comboBoxDrainChMeasMode.Size = new System.Drawing.Size(127, 21);
            this.comboBoxDrainChMeasMode.TabIndex = 3;
            this.comboBoxDrainChMeasMode.SelectedIndexChanged += new System.EventHandler(this.comboBoxDrainChMeasMode_SelectedIndexChanged);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(411, 9);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(158, 18);
            this.label59.TabIndex = 41;
            this.label59.Text = "Measurement Setup";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(187, 9);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(105, 18);
            this.label58.TabIndex = 42;
            this.label58.Text = "Stress Setup";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 18);
            this.label2.TabIndex = 11;
            this.label2.Text = "Channel Setup";
            // 
            // tabChannelSetup
            // 
            this.tabChannelSetup.Controls.Add(this.tabGateChSetup);
            this.tabChannelSetup.Controls.Add(this.tabDrainChSetup);
            this.tabChannelSetup.Controls.Add(this.tabPage1);
            this.tabChannelSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabChannelSetup.Location = new System.Drawing.Point(10, 31);
            this.tabChannelSetup.Name = "tabChannelSetup";
            this.tabChannelSetup.SelectedIndex = 0;
            this.tabChannelSetup.Size = new System.Drawing.Size(169, 433);
            this.tabChannelSetup.TabIndex = 0;
            this.tabChannelSetup.SelectedIndexChanged += new System.EventHandler(this.comboBoxDrainCh_SelectedIndexChanged);
            // 
            // tabGateChSetup
            // 
            this.tabGateChSetup.Controls.Add(this.comboBoxGateChIMeasRange);
            this.tabGateChSetup.Controls.Add(this.label64);
            this.tabGateChSetup.Controls.Add(this.comboBoxGateCh);
            this.tabGateChSetup.Controls.Add(this.label30);
            this.tabGateChSetup.Controls.Add(this.comboBoxGateChVMeasRange);
            this.tabGateChSetup.Controls.Add(this.comboBoxGateChForceRange);
            this.tabGateChSetup.Controls.Add(this.comboBoxGateChMeasMode);
            this.tabGateChSetup.Controls.Add(this.comboBoxGateChOperationMode);
            this.tabGateChSetup.Controls.Add(this.textBoxGateChHwSkew);
            this.tabGateChSetup.Controls.Add(this.label32);
            this.tabGateChSetup.Controls.Add(this.label3);
            this.tabGateChSetup.Controls.Add(this.label5);
            this.tabGateChSetup.Controls.Add(this.checkBoxGateMeas);
            this.tabGateChSetup.Controls.Add(this.label45);
            this.tabGateChSetup.Controls.Add(this.label29);
            this.tabGateChSetup.Location = new System.Drawing.Point(4, 22);
            this.tabGateChSetup.Name = "tabGateChSetup";
            this.tabGateChSetup.Padding = new System.Windows.Forms.Padding(3);
            this.tabGateChSetup.Size = new System.Drawing.Size(161, 407);
            this.tabGateChSetup.TabIndex = 0;
            this.tabGateChSetup.Text = "Gate";
            this.tabGateChSetup.UseVisualStyleBackColor = true;
            // 
            // comboBoxGateChIMeasRange
            // 
            this.comboBoxGateChIMeasRange.FormattingEnabled = true;
            this.comboBoxGateChIMeasRange.Items.AddRange(new object[] {
            "+/-1 uA Fixed",
            "+/-10 uA Fixed",
            "+/-100 uA Fixed",
            "+/-1 mA Fixed",
            "+/-10 mA Fixed"});
            this.comboBoxGateChIMeasRange.Location = new System.Drawing.Point(19, 203);
            this.comboBoxGateChIMeasRange.Name = "comboBoxGateChIMeasRange";
            this.comboBoxGateChIMeasRange.Size = new System.Drawing.Size(127, 21);
            this.comboBoxGateChIMeasRange.TabIndex = 5;
            // 
            // label64
            // 
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(6, 186);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(140, 17);
            this.label64.TabIndex = 23;
            this.label64.Text = "Current Range";
            // 
            // comboBoxGateCh
            // 
            this.comboBoxGateCh.FormattingEnabled = true;
            this.comboBoxGateCh.Items.AddRange(new object[] {
            "101",
            "102",
            "201",
            "202",
            "301",
            "302",
            "401",
            "402",
            "501",
            "502",
            "601",
            "602",
            "701",
            "702",
            "801",
            "802",
            "901",
            "902",
            "1001",
            "1002"});
            this.comboBoxGateCh.Location = new System.Drawing.Point(52, 31);
            this.comboBoxGateCh.Name = "comboBoxGateCh";
            this.comboBoxGateCh.Size = new System.Drawing.Size(78, 21);
            this.comboBoxGateCh.TabIndex = 1;
            this.comboBoxGateCh.SelectedIndexChanged += new System.EventHandler(this.comboBoxGateCh_SelectedIndexChanged);
            // 
            // label30
            // 
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(6, 34);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(40, 16);
            this.label30.TabIndex = 21;
            this.label30.Text = "Gate";
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(6, 141);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(130, 18);
            this.label29.TabIndex = 16;
            this.label29.Text = "Voltage Force Range";
            // 
            // tabDrainChSetup
            // 
            this.tabDrainChSetup.Controls.Add(this.comboBoxDrainChIMeasRange);
            this.tabDrainChSetup.Controls.Add(this.label62);
            this.tabDrainChSetup.Controls.Add(this.comboBoxDrainCh);
            this.tabDrainChSetup.Controls.Add(this.label1);
            this.tabDrainChSetup.Controls.Add(this.comboBoxDrainChVMeasRange);
            this.tabDrainChSetup.Controls.Add(this.comboBoxDrainChForceRange);
            this.tabDrainChSetup.Controls.Add(this.comboBoxDrainChMeasMode);
            this.tabDrainChSetup.Controls.Add(this.comboBoxDrainChOperationMode);
            this.tabDrainChSetup.Controls.Add(this.textBoxDrainChHwSkew);
            this.tabDrainChSetup.Controls.Add(this.label33);
            this.tabDrainChSetup.Controls.Add(this.label46);
            this.tabDrainChSetup.Controls.Add(this.label47);
            this.tabDrainChSetup.Controls.Add(this.checkBoxDrainMeas);
            this.tabDrainChSetup.Controls.Add(this.label48);
            this.tabDrainChSetup.Controls.Add(this.label51);
            this.tabDrainChSetup.Location = new System.Drawing.Point(4, 22);
            this.tabDrainChSetup.Name = "tabDrainChSetup";
            this.tabDrainChSetup.Padding = new System.Windows.Forms.Padding(3);
            this.tabDrainChSetup.Size = new System.Drawing.Size(161, 407);
            this.tabDrainChSetup.TabIndex = 1;
            this.tabDrainChSetup.Text = "Drain";
            this.tabDrainChSetup.UseVisualStyleBackColor = true;
            this.tabDrainChSetup.Click += new System.EventHandler(this.tabDrainChSetup_Click);
            // 
            // comboBoxDrainChIMeasRange
            // 
            this.comboBoxDrainChIMeasRange.FormattingEnabled = true;
            this.comboBoxDrainChIMeasRange.Items.AddRange(new object[] {
            "+/-1 uA Fixed",
            "+/-10 uA Fixed",
            "+/-100 uA Fixed",
            "+/-1 mA Fixed",
            "+/-10 mA Fixed"});
            this.comboBoxDrainChIMeasRange.Location = new System.Drawing.Point(19, 203);
            this.comboBoxDrainChIMeasRange.Name = "comboBoxDrainChIMeasRange";
            this.comboBoxDrainChIMeasRange.Size = new System.Drawing.Size(127, 21);
            this.comboBoxDrainChIMeasRange.TabIndex = 5;
            // 
            // label62
            // 
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(6, 186);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(140, 17);
            this.label62.TabIndex = 8;
            this.label62.Text = "Current Range";
            // 
            // comboBoxDrainCh
            // 
            this.comboBoxDrainCh.FormattingEnabled = true;
            this.comboBoxDrainCh.Items.AddRange(new object[] {
            "101",
            "102",
            "201",
            "202",
            "301",
            "302",
            "401",
            "402",
            "501",
            "502",
            "601",
            "602",
            "701",
            "702",
            "801",
            "802",
            "901",
            "902",
            "1001",
            "1002"});
            this.comboBoxDrainCh.Location = new System.Drawing.Point(52, 31);
            this.comboBoxDrainCh.Name = "comboBoxDrainCh";
            this.comboBoxDrainCh.Size = new System.Drawing.Size(78, 21);
            this.comboBoxDrainCh.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 31;
            this.label1.Text = "Drain";
            // 
            // comboBoxDrainChVMeasRange
            // 
            this.comboBoxDrainChVMeasRange.FormattingEnabled = true;
            this.comboBoxDrainChVMeasRange.Items.AddRange(new object[] {
            "+/-5 V",
            "+/-10 V"});
            this.comboBoxDrainChVMeasRange.Location = new System.Drawing.Point(19, 263);
            this.comboBoxDrainChVMeasRange.Name = "comboBoxDrainChVMeasRange";
            this.comboBoxDrainChVMeasRange.Size = new System.Drawing.Size(127, 21);
            this.comboBoxDrainChVMeasRange.TabIndex = 6;
            this.comboBoxDrainChVMeasRange.SelectedIndexChanged += new System.EventHandler(this.comboBoxDrainChVMeasRange_SelectedIndexChanged);
            // 
            // comboBoxDrainChForceRange
            // 
            this.comboBoxDrainChForceRange.FormattingEnabled = true;
            this.comboBoxDrainChForceRange.Items.AddRange(new object[] {
            "+/-5 V",
            "-10 V to 0 V",
            "0 V to +10 V"});
            this.comboBoxDrainChForceRange.Location = new System.Drawing.Point(19, 158);
            this.comboBoxDrainChForceRange.Name = "comboBoxDrainChForceRange";
            this.comboBoxDrainChForceRange.Size = new System.Drawing.Size(127, 21);
            this.comboBoxDrainChForceRange.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(161, 407);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Bias";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.textBoxBiasSource2BiasV);
            this.groupBox7.Controls.Add(this.label66);
            this.groupBox7.Controls.Add(this.label70);
            this.groupBox7.Controls.Add(this.label71);
            this.groupBox7.Controls.Add(this.comboBoxBiasSource2Type);
            this.groupBox7.Controls.Add(this.label72);
            this.groupBox7.Controls.Add(this.comboBoxBiasSource2Ch);
            this.groupBox7.Controls.Add(this.textBoxBiasSource2Compliance);
            this.groupBox7.Location = new System.Drawing.Point(4, 202);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(152, 193);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Bias Source2";
            // 
            // textBoxBiasSource2BiasV
            // 
            this.textBoxBiasSource2BiasV.Location = new System.Drawing.Point(14, 120);
            this.textBoxBiasSource2BiasV.Name = "textBoxBiasSource2BiasV";
            this.textBoxBiasSource2BiasV.Size = new System.Drawing.Size(56, 20);
            this.textBoxBiasSource2BiasV.TabIndex = 2;
            this.textBoxBiasSource2BiasV.Text = "0.0";
            this.textBoxBiasSource2BiasV.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxBiasSource2BiasV_Validating);
            // 
            // label66
            // 
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(13, 143);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(94, 18);
            this.label66.TabIndex = 38;
            this.label66.Text = "Compliance (A)";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label70
            // 
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(10, 104);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(94, 15);
            this.label70.TabIndex = 36;
            this.label70.Text = "Bias (V)";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label71
            // 
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(10, 19);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(120, 16);
            this.label71.TabIndex = 30;
            this.label71.Text = "Module Type";
            // 
            // comboBoxBiasSource2Type
            // 
            this.comboBoxBiasSource2Type.FormattingEnabled = true;
            this.comboBoxBiasSource2Type.Items.AddRange(new object[] {
            "N/A",
            "WGFMU",
            "SMU"});
            this.comboBoxBiasSource2Type.Location = new System.Drawing.Point(13, 38);
            this.comboBoxBiasSource2Type.Name = "comboBoxBiasSource2Type";
            this.comboBoxBiasSource2Type.Size = new System.Drawing.Size(127, 21);
            this.comboBoxBiasSource2Type.TabIndex = 0;
            this.comboBoxBiasSource2Type.SelectedIndexChanged += new System.EventHandler(this.comboBoxBiasSource2Type_SelectedIndexChanged);
            // 
            // label72
            // 
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(10, 62);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(124, 13);
            this.label72.TabIndex = 34;
            this.label72.Text = "Channel ID";
            // 
            // comboBoxBiasSource2Ch
            // 
            this.comboBoxBiasSource2Ch.FormattingEnabled = true;
            this.comboBoxBiasSource2Ch.Items.AddRange(new object[] {
            "101",
            "102",
            "201",
            "202",
            "301",
            "302",
            "401",
            "402",
            "501",
            "502",
            "601",
            "602",
            "701",
            "702",
            "801",
            "802",
            "901",
            "902",
            "1001",
            "1002"});
            this.comboBoxBiasSource2Ch.Location = new System.Drawing.Point(14, 78);
            this.comboBoxBiasSource2Ch.Name = "comboBoxBiasSource2Ch";
            this.comboBoxBiasSource2Ch.Size = new System.Drawing.Size(78, 21);
            this.comboBoxBiasSource2Ch.TabIndex = 1;
            this.comboBoxBiasSource2Ch.SelectedIndexChanged += new System.EventHandler(this.comboBoxBiasSource2Ch_SelectedIndexChanged);
            // 
            // textBoxBiasSource2Compliance
            // 
            this.textBoxBiasSource2Compliance.Location = new System.Drawing.Point(17, 164);
            this.textBoxBiasSource2Compliance.Name = "textBoxBiasSource2Compliance";
            this.textBoxBiasSource2Compliance.Size = new System.Drawing.Size(56, 20);
            this.textBoxBiasSource2Compliance.TabIndex = 3;
            this.textBoxBiasSource2Compliance.Text = "0.0";
            this.textBoxBiasSource2Compliance.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxBiasSource2Compliance_Validating);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBoxBiasSource1BiasV);
            this.groupBox6.Controls.Add(this.label69);
            this.groupBox6.Controls.Add(this.label68);
            this.groupBox6.Controls.Add(this.label65);
            this.groupBox6.Controls.Add(this.comboBoxBiasSource1Type);
            this.groupBox6.Controls.Add(this.label67);
            this.groupBox6.Controls.Add(this.comboBoxBiasSource1Ch);
            this.groupBox6.Controls.Add(this.textBoxBiasSource1Compliance);
            this.groupBox6.Location = new System.Drawing.Point(4, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(152, 193);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Bias Source1";
            // 
            // textBoxBiasSource1BiasV
            // 
            this.textBoxBiasSource1BiasV.Location = new System.Drawing.Point(14, 120);
            this.textBoxBiasSource1BiasV.Name = "textBoxBiasSource1BiasV";
            this.textBoxBiasSource1BiasV.Size = new System.Drawing.Size(56, 20);
            this.textBoxBiasSource1BiasV.TabIndex = 2;
            this.textBoxBiasSource1BiasV.Text = "0.0";
            this.textBoxBiasSource1BiasV.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxBiasSource1BiasV_Validating);
            // 
            // label69
            // 
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(13, 143);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(94, 18);
            this.label69.TabIndex = 38;
            this.label69.Text = "Compliance (A)";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label68
            // 
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(10, 104);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(94, 15);
            this.label68.TabIndex = 36;
            this.label68.Text = "Bias (V)";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label65
            // 
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(10, 19);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(120, 16);
            this.label65.TabIndex = 30;
            this.label65.Text = "Module Type";
            // 
            // comboBoxBiasSource1Type
            // 
            this.comboBoxBiasSource1Type.FormattingEnabled = true;
            this.comboBoxBiasSource1Type.Items.AddRange(new object[] {
            "N/A",
            "WGFMU",
            "SMU"});
            this.comboBoxBiasSource1Type.Location = new System.Drawing.Point(13, 38);
            this.comboBoxBiasSource1Type.Name = "comboBoxBiasSource1Type";
            this.comboBoxBiasSource1Type.Size = new System.Drawing.Size(127, 21);
            this.comboBoxBiasSource1Type.TabIndex = 0;
            this.comboBoxBiasSource1Type.SelectedIndexChanged += new System.EventHandler(this.comboBoxBiasSource1Type_SelectedIndexChanged);
            // 
            // label67
            // 
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(10, 62);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(124, 13);
            this.label67.TabIndex = 34;
            this.label67.Text = "Channel ID";
            // 
            // comboBoxBiasSource1Ch
            // 
            this.comboBoxBiasSource1Ch.FormattingEnabled = true;
            this.comboBoxBiasSource1Ch.Items.AddRange(new object[] {
            "101",
            "102",
            "201",
            "202",
            "301",
            "302",
            "401",
            "402",
            "501",
            "502",
            "601",
            "602",
            "701",
            "702",
            "801",
            "802",
            "901",
            "902",
            "1001",
            "1002"});
            this.comboBoxBiasSource1Ch.Location = new System.Drawing.Point(14, 78);
            this.comboBoxBiasSource1Ch.Name = "comboBoxBiasSource1Ch";
            this.comboBoxBiasSource1Ch.Size = new System.Drawing.Size(78, 21);
            this.comboBoxBiasSource1Ch.TabIndex = 1;
            this.comboBoxBiasSource1Ch.SelectedIndexChanged += new System.EventHandler(this.comboBoxBiasSource1Ch_SelectedIndexChanged);
            // 
            // textBoxBiasSource1Compliance
            // 
            this.textBoxBiasSource1Compliance.Location = new System.Drawing.Point(17, 164);
            this.textBoxBiasSource1Compliance.Name = "textBoxBiasSource1Compliance";
            this.textBoxBiasSource1Compliance.Size = new System.Drawing.Size(56, 20);
            this.textBoxBiasSource1Compliance.TabIndex = 3;
            this.textBoxBiasSource1Compliance.Text = "0.0";
            this.textBoxBiasSource1Compliance.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxBiasSource1Compliance_Validating);
            // 
            // tabOTFSetup
            // 
            this.tabOTFSetup.Controls.Add(this.label53);
            this.tabOTFSetup.Controls.Add(this.label54);
            this.tabOTFSetup.Controls.Add(this.label55);
            this.tabOTFSetup.Controls.Add(this.label44);
            this.tabOTFSetup.Controls.Add(this.label56);
            this.tabOTFSetup.Controls.Add(this.textBoxOTFStepDelay);
            this.tabOTFSetup.Controls.Add(this.label57);
            this.tabOTFSetup.Controls.Add(this.textBoxOTFMeasDelay);
            this.tabOTFSetup.Controls.Add(this.textBoxOTFdVg);
            this.tabOTFSetup.Controls.Add(this.textBoxOTFVd);
            this.tabOTFSetup.Controls.Add(this.textBoxOTFEdge);
            this.tabOTFSetup.Controls.Add(this.textBoxOTFMeasAveragingTime);
            this.tabOTFSetup.Location = new System.Drawing.Point(4, 22);
            this.tabOTFSetup.Name = "tabOTFSetup";
            this.tabOTFSetup.Padding = new System.Windows.Forms.Padding(3);
            this.tabOTFSetup.Size = new System.Drawing.Size(205, 405);
            this.tabOTFSetup.TabIndex = 3;
            this.tabOTFSetup.Text = "OTF";
            this.tabOTFSetup.UseVisualStyleBackColor = true;
            // 
            // label44
            // 
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(6, 184);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(88, 28);
            this.label44.TabIndex = 20;
            this.label44.Text = "Step Delay (s)";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxOTFStepDelay
            // 
            this.textBoxOTFStepDelay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxOTFStepDelay.Location = new System.Drawing.Point(113, 187);
            this.textBoxOTFStepDelay.Name = "textBoxOTFStepDelay";
            this.textBoxOTFStepDelay.Size = new System.Drawing.Size(56, 22);
            this.textBoxOTFStepDelay.TabIndex = 5;
            this.textBoxOTFStepDelay.Text = "10E-9";
            this.textBoxOTFStepDelay.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxOTFStepDelay_Validating);
            // 
            // tabMeasurementSetup
            // 
            this.tabMeasurementSetup.Controls.Add(this.tabMeasSequenceSetup);
            this.tabMeasurementSetup.Controls.Add(this.tabSamplingSetup);
            this.tabMeasurementSetup.Controls.Add(this.tabSweepSetup);
            this.tabMeasurementSetup.Controls.Add(this.tabPivSetup);
            this.tabMeasurementSetup.Controls.Add(this.tabOTFSetup);
            this.tabMeasurementSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabMeasurementSetup.Location = new System.Drawing.Point(410, 31);
            this.tabMeasurementSetup.Name = "tabMeasurementSetup";
            this.tabMeasurementSetup.SelectedIndex = 0;
            this.tabMeasurementSetup.Size = new System.Drawing.Size(213, 431);
            this.tabMeasurementSetup.TabIndex = 2;
            // 
            // tabSweepSetup
            // 
            this.tabSweepSetup.Controls.Add(this.label15);
            this.tabSweepSetup.Controls.Add(this.comboBoxSweepType);
            this.tabSweepSetup.Controls.Add(this.groupBox3);
            this.tabSweepSetup.Controls.Add(this.groupVgSweep);
            this.tabSweepSetup.Controls.Add(this.checkBoxDualSweep);
            this.tabSweepSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabSweepSetup.Location = new System.Drawing.Point(4, 22);
            this.tabSweepSetup.Name = "tabSweepSetup";
            this.tabSweepSetup.Padding = new System.Windows.Forms.Padding(3);
            this.tabSweepSetup.Size = new System.Drawing.Size(205, 405);
            this.tabSweepSetup.TabIndex = 1;
            this.tabSweepSetup.Text = "Sweep";
            this.tabSweepSetup.UseVisualStyleBackColor = true;
            // 
            // buttonConfig
            // 
            this.buttonConfig.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConfig.Location = new System.Drawing.Point(438, 470);
            this.buttonConfig.Name = "buttonConfig";
            this.buttonConfig.Size = new System.Drawing.Size(75, 41);
            this.buttonConfig.TabIndex = 7;
            this.buttonConfig.Text = "Config";
            this.buttonConfig.Click += new System.EventHandler(this.buttonConfig_Click);
            // 
            // buttonSaveSetup
            // 
            this.buttonSaveSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSaveSetup.Location = new System.Drawing.Point(228, 470);
            this.buttonSaveSetup.Name = "buttonSaveSetup";
            this.buttonSaveSetup.Size = new System.Drawing.Size(75, 41);
            this.buttonSaveSetup.TabIndex = 5;
            this.buttonSaveSetup.Text = "Save Setup";
            this.buttonSaveSetup.Click += new System.EventHandler(this.buttonSaveSetup_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // NBTI_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(631, 523);
            this.Controls.Add(this.buttonLoad);
            this.Controls.Add(this.buttonExecMeas);
            this.Controls.Add(this.validPattern);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.tabStressSetup);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tabChannelSetup);
            this.Controls.Add(this.tabMeasurementSetup);
            this.Controls.Add(this.buttonSaveSetup);
            this.Controls.Add(this.buttonConfig);
            this.MaximizeBox = false;
            this.Name = "NBTI_Form";
            this.Text = "NBTI / PBTI";
            this.Load += new System.EventHandler(this.NBTI_Form_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupVgSweep.ResumeLayout(false);
            this.groupVgSweep.PerformLayout();
            this.tabMeasSequenceSetup.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupSweepVgPulse.ResumeLayout(false);
            this.groupSweepVgPulse.PerformLayout();
            this.groupSweepVdPulse.ResumeLayout(false);
            this.groupSweepVdPulse.PerformLayout();
            this.tabSamplingSetup.ResumeLayout(false);
            this.tabSamplingSetup.PerformLayout();
            this.tabStressSetup.ResumeLayout(false);
            this.tabAccStressTimeSetup.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataViewStressList)).EndInit();
            this.tabStressVgSetup.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupACStressVgPulse.ResumeLayout(false);
            this.groupACStressVgPulse.PerformLayout();
            this.tabStressVdSetup.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupVdACStress.ResumeLayout(false);
            this.groupVdACStress.PerformLayout();
            this.tabPivSetup.ResumeLayout(false);
            this.tabChannelSetup.ResumeLayout(false);
            this.tabGateChSetup.ResumeLayout(false);
            this.tabGateChSetup.PerformLayout();
            this.tabDrainChSetup.ResumeLayout(false);
            this.tabDrainChSetup.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabOTFSetup.ResumeLayout(false);
            this.tabOTFSetup.PerformLayout();
            this.tabMeasurementSetup.ResumeLayout(false);
            this.tabSweepSetup.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxSweepVgStart;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBoxSweepVgStop;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBoxSweepVd;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxSweepStepNum;
        private System.Windows.Forms.TextBox textBoxSweepDelayDualSweep;
        private System.Windows.Forms.TextBox textBoxSweepHold;
        private System.Windows.Forms.TextBox textBoxSweepDelay;
        private System.Windows.Forms.TextBox textBoxSweepAveragingTime;
        private System.Windows.Forms.TextBox textBoxSweepStepRise;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBoxSamplingMeasAveragingTime;
        private System.Windows.Forms.ComboBox comboBoxSamplingMode;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBoxSamplingMeasDelay;
        private System.Windows.Forms.TextBox textBoxSamplingHold;
        private System.Windows.Forms.ComboBox comboBoxSweepType;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBoxSamplingMeasInterval;
        private System.Windows.Forms.GroupBox groupVgSweep;
        private System.Windows.Forms.TextBox textBoxSamplingVg;
        private System.Windows.Forms.TextBox textBoxSamplingVd;
        private System.Windows.Forms.TextBox textBoxSampingMeasPoints;
        private System.Windows.Forms.TabPage tabMeasSequenceSetup;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButtonOTF;
        private System.Windows.Forms.RadioButton radioButtonSweep;
        private System.Windows.Forms.RadioButton radioButtonSampling;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBoxStressDelayReferenceMeas;
        private System.Windows.Forms.CheckBox checkBoxReferenceMeas;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBoxMeasIntervalMode;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox textBoxMeasIterationNumber;
        private System.Windows.Forms.TextBox textBoxIterativeMeasInterval;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBoxSweepVdPulseBase;
        private System.Windows.Forms.TextBox textBoxOTFMeasDelay;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBoxSweepVdPulseWidth;
        private System.Windows.Forms.TextBox textBoxOTFdVg;
        private System.Windows.Forms.TextBox textBoxOTFVd;
        private System.Windows.Forms.Button buttonLoad;
        private System.Windows.Forms.TextBox textBoxOTFMeasAveragingTime;
        private System.Windows.Forms.Button buttonExecMeas;
        private System.Windows.Forms.TextBox textBoxOTFEdge;
        private System.Windows.Forms.Button validPattern;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.TextBox textBoxSweepPulsePeriod;
        private System.Windows.Forms.TextBox textBoxSweepVgPulseBase;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label Labelx2;
        private System.Windows.Forms.Label Labelx4;
        private System.Windows.Forms.Label Labelx3;
        private System.Windows.Forms.TextBox textBoxSweepVdPulseDelay;
        private System.Windows.Forms.CheckBox checkBoxDualSweep;
        private System.Windows.Forms.GroupBox groupSweepVgPulse;
        private System.Windows.Forms.TextBox textBoxSweepVgPulseWidth;
        private System.Windows.Forms.TextBox textBoxSweepVgPulseLeadingEdge;
        private System.Windows.Forms.TextBox textBoxSweepVgPulseDelay;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.CheckBox checkBoxSweepVdPulse;
        private System.Windows.Forms.GroupBox groupSweepVdPulse;
        private System.Windows.Forms.TabPage tabSamplingSetup;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.CheckBox checkBoxDrainMeas;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox comboBoxGateChForceRange;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.ComboBox comboBoxGateChMeasMode;
        private System.Windows.Forms.ComboBox comboBoxGateChOperationMode;
        private System.Windows.Forms.TabControl tabStressSetup;
        private System.Windows.Forms.TabPage tabAccStressTimeSetup;
        private System.Windows.Forms.TabPage tabStressVgSetup;
        private System.Windows.Forms.GroupBox groupACStressVgPulse;
        private System.Windows.Forms.ComboBox comboBoxStressPulseFreq;
        private System.Windows.Forms.TextBox textBoxStressVgBase;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxStressVgPulseDuty;
        private System.Windows.Forms.TextBox textBoxStressVgPulseLeadingEdge;
        private System.Windows.Forms.TextBox textBoxStressVg;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton radioButtonDCStress;
        private System.Windows.Forms.RadioButton radioButtonPulseStress;
        private System.Windows.Forms.TabPage tabStressVdSetup;
        private System.Windows.Forms.TextBox textBoxStressVd;
        private System.Windows.Forms.CheckBox checkBoxVdPulseStress;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupVdACStress;
        private System.Windows.Forms.TextBox textBoxStressVdPulseBase;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBoxStressVdPulseDuty;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBoxStressVdPulseLeadingEdge;
        private System.Windows.Forms.Label Labelx1;
        private System.Windows.Forms.TextBox textBoxStressVdPulseDelay;
        private System.Windows.Forms.TextBox textBoxGateChHwSkew;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TabPage tabPivSetup;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox checkBoxGateMeas;
        private System.Windows.Forms.TextBox textBoxDrainChHwSkew;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox comboBoxDrainChOperationMode;
        private System.Windows.Forms.ComboBox comboBoxDrainChMeasMode;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabChannelSetup;
        private System.Windows.Forms.TabPage tabGateChSetup;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TabPage tabDrainChSetup;
        private System.Windows.Forms.ComboBox comboBoxDrainChVMeasRange;
        private System.Windows.Forms.ComboBox comboBoxDrainChForceRange;
        private System.Windows.Forms.TabPage tabOTFSetup;
        private System.Windows.Forms.TabControl tabMeasurementSetup;
        private System.Windows.Forms.TabPage tabSweepSetup;
        private System.Windows.Forms.Button buttonConfig;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxStressVgPulseDelay;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBoxStressToMeasEdge;
        private System.Windows.Forms.TextBox textBoxVdSequenceDelay;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox textBoxSweepVdPulseLeadingEdge;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dataViewStressList;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBoxSamplingExtraDelay;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBoxSweepStepDelay;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBoxOTFStepDelay;
        private System.Windows.Forms.Button buttonSaveSetup;
        private System.Windows.Forms.CheckBox checkBoxEnablePostMeas;
        private System.Windows.Forms.ComboBox comboBoxGateCh;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox comboBoxDrainChIMeasRange;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.ComboBox comboBoxDrainCh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxGateChIMeasRange;
        private System.Windows.Forms.Label label64;
        public System.Windows.Forms.ComboBox comboBoxGateChVMeasRange;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ComboBox comboBoxBiasSource1Type;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox textBoxBiasSource1Compliance;
        private System.Windows.Forms.TextBox textBoxBiasSource1BiasV;
        private System.Windows.Forms.ComboBox comboBoxBiasSource1Ch;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBoxBiasSource2BiasV;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.ComboBox comboBoxBiasSource2Type;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.ComboBox comboBoxBiasSource2Ch;
        private System.Windows.Forms.TextBox textBoxBiasSource2Compliance;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridViewTextBoxColumn StressNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn ListAccumulatedStressTime;
        private System.Windows.Forms.TextBox textBoxPostMeasDelay;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox comboBoxVgStressCurrentRange;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.ComboBox comboBoxVdStressCurrentRange;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox textBoxVdRangeChangeHold;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox textBoxVgRangeChangeHold;
        private System.Windows.Forms.Label label77;
    }
}

